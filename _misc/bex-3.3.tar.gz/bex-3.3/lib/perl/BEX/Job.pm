# Batch EXecutor -- Jobs
# (c) 2011-2015 Martin Mares <mj@ucw.cz>

use strict;
use warnings;

package BEX::Job;

use POSIX ();
use Digest::SHA;

our $job_cnt = 0;

sub check_id($) {
	my ($id) = @_;
	return $id =~ /^([0-9A-Za-z-]+)$/;
}

sub new($;$) {
	my ($class, $id) = @_;
	my $job = { };
	bless $job;
	if (defined $id) {
		check_id($id) or die "Invalid job ID";
		$job->{'ID'} = $id;
	} else {
		$job_cnt++;
		my $dt = POSIX::strftime("%Y%m%d-%H%M%S", localtime);
		my $hash = Digest::SHA::sha1_hex(join(":", $dt, $$, $job_cnt));
		$job->{'ID'} = $dt . '-' . substr($hash, 0, 8);
	}
	$job->{'Subject'} = '';
	return $job;
}

sub new_from_file($$;$) {
	my ($class, $file, $header_only) = @_;
	my $job = { };
	open T, '<', $file or die "Cannot open $file: $!";
	while (<T>) {
		chomp;
		/^$/ and last;
		/^([A-Z][A-Za-z0-9-]*):\s*(.*)/ or die "Cannot load $file: Header syntax error";
		!defined $job->{$1} or die "Cannot load $file: Header $1 re-defined";
		$job->{$1} = $2;
	}
	if (!$header_only) {
		my @cmds = <T>;
		$job->{'body'} = join("", @cmds);
	}
	close T;
	$job->{'Subject'} //= '';
	$job->{'ID'} or die "Cannot load $file: Missing ID";
	check_id($job->{'ID'}) or die "Cannot load $file: Invalid ID syntax";
	return bless $job;
}

sub id($) {
	return $_[0]->{'ID'};
}

sub name($) {
	my ($job) = @_;
	my $name = $job->{'ID'};
	my $subj = $job->{'Subject'} // "";
	$name .= " ($subj)" if $subj !~ /^\s*$/;
	return $name;
}

sub attr($$;$) {
	my ($job, $attr, $val) = @_;
	$job->{$attr} = $val if defined $val;
	return $job->{$attr};
}

sub dump($) {
	my ($job) = @_;
	for my $k (sort keys %$job) {
		print "$k: ", $job->{$k}, "\n";
	}
}

sub save($;$) {
	my ($job, $fn) = @_;
	my $tmp = $BEX::Config::home . "/tmp";
	-d $tmp or mkdir $tmp or die "Cannot create directory $tmp: $!";
	$fn //= $tmp . '/' . $job->id;
	open T, '>', $fn or die "Cannot create $fn: $!";
	for my $k (sort grep { /^[A-Z]/ } keys %$job) {
		print T "$k: ", $job->{$k}, "\n";
	}
	print T "\n";
	print T $job->{'body'} if defined $job->{'body'};
	close T;
	return $fn;
}

42;
