# Batch EXecutor
# (c) 2011-2012 Martin Mares <mj@ucw.cz>

use strict;
use warnings;

package BEX;

use BEX::Config;
use BEX::Job;
use BEX::Queue;

42;
