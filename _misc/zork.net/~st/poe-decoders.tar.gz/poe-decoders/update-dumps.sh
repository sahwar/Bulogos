#!/bin/sh
set -e


if [ "$1" = "" ]; then
	echo "Usage: $0 /path/to/Client.txt"
	exit 1
fi

BASEDIR=$(dirname "$0")
BASE_URL=$(grep -o "http://patchcdn[-.a-z0-9/]*" "$1" | tail -n 1)
VERSION=$(basename "$BASE_URL")
DECODABLES="
	Data/NPCTextAudio.dat decode-npc-text.py
	Data/FlavourText.dat decode-flavour-text.py
"

echo "$DECODABLES" | while read URL_PATH DECODER; do
	if [ "$URL_PATH" = "" ]; then continue; fi

	DEST_PATH="$BASEDIR"/"$VERSION"/$(basename "$URL_PATH")
	DECODED_PATH="$DEST_PATH".txt

	mkdir -p $(dirname "$DEST_PATH")

	if [ ! -f "$DEST_PATH" ]; then
		echo "Downloading to $DEST_PATH ..."
		wget -c -O "$DEST_PATH" "$BASE_URL""$URL_PATH"
	else
		echo "Already downloaded $DEST_PATH"
	fi

	if [ ! -f "$DECODED_PATH" ]; then
		echo "Decoding to $DECODED_PATH ..."
		"$BASEDIR"/"$DECODER" "$DEST_PATH" > "$DECODED_PATH"
	else
		echo "Already decoded $DECODED_PATH"
	fi
done
