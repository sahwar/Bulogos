#!/usr/bin/python3
import sys
import struct
from textwrap import wrap

STRUCT_HEADER = struct.Struct("<1I")
STRUCT_TOC_ENTRY = struct.Struct("<5I")

CLASS_FLAG_DESCRIPTIONS = {
		0: "Marauder",
		1: "Witch",
		3: "Ranger",
		4: "Duelist",
		5: "Shadow",
		6: "Templar",
	}

with open(sys.argv[1], 'rb') as handle:
	header = STRUCT_HEADER.unpack(handle.read(STRUCT_HEADER.size))

	toc = [
			STRUCT_TOC_ENTRY.unpack(handle.read(STRUCT_TOC_ENTRY.size))
			for i in range(header[0])
		]

	textdata = handle.read()

messages = [
		(
			classFlag, unknown,
			textdata[nameStart:textStart-4].decode("utf_16_le"),
			textdata[textStart:filenameStart-4].decode("utf_16_le").split("\n"),
		)

		for nameStart, classFlag, unknown, textStart, filenameStart in toc
	]

for classFlag, unknown, name, text in messages:
	print("Name:", name)
	if classFlag in CLASS_FLAG_DESCRIPTIONS:
		print("For class:", CLASS_FLAG_DESCRIPTIONS[classFlag])

	print()

	for paragraph in text:
		if paragraph.strip():
			for line in wrap(paragraph):
				print(line)
			print()
