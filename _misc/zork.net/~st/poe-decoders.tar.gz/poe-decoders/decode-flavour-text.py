#!/usr/bin/python3
import sys
import struct
from textwrap import wrap

STRUCT_HEADER = struct.Struct("<1I")
STRUCT_TOC_ENTRY = struct.Struct("<3I")

with open(sys.argv[1], 'rb') as handle:
	header = STRUCT_HEADER.unpack(handle.read(STRUCT_HEADER.size))

	toc = [
			STRUCT_TOC_ENTRY.unpack(handle.read(STRUCT_TOC_ENTRY.size))
			for i in range(header[0])
		]

	textdata = handle.read()

lastNameStart = -1
lastTextStart = -1
messages = []

for nameStart, unknown, textStart in toc:
	if lastNameStart > -1:
		messages.append((
				textdata[lastNameStart:lastTextStart-4].decode("utf_16_le"),
				textdata[lastTextStart:nameStart-4].decode("utf_16_le"),
			))

	lastNameStart = nameStart
	lastTextStart = textStart

messages.append((
		textdata[lastNameStart:lastTextStart-4].decode("utf_16_le"),
		textdata[lastTextStart:-4].decode("utf_16_le"),
	))

for name, text in messages:
	print("Name:", name)

	print()

	for paragraph in text.split("\n"):
		if paragraph.strip():
			for line in wrap(paragraph):
				print(line)

	print()
