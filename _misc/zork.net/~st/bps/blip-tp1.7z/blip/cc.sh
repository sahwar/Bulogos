g++-4.5 -std=gnu++0x -s -O3 -fomit-frame-pointer -I. -o blip blip.cpp
