#include <nall/crc32.hpp>
#include <nall/file.hpp>
#include <nall/filemap.hpp>
#include <nall/stdint.hpp>
using namespace nall;

struct blpDelta {
  enum { granularity = 16 };

  file modFile;
  uint32_t modChecksum;

  uint8_t *oldData;
  unsigned oldSize;
  unsigned oldOffset;

  uint8_t *newData;
  unsigned newSize;
  unsigned newOffset;

  unsigned outOffset;

  void write(uint8_t data) {
    modFile.write(data);
    modChecksum = crc32_adjust(modChecksum, data);
  }

  void encode(uint64_t offset) {
    while(true) {
      uint64_t x = offset & 0x7f;
      offset >>= 7;
      if(offset == 0) {
        write(0x80 | x);
        break;
      }
      write(x);
      offset--;
    }
  }

  unsigned getLZ(unsigned startOffset, unsigned &outOffset, bool &outSource) {
    unsigned outLength = 0;

    for(unsigned offset = 0; offset < oldSize; offset++) {
      unsigned x = offset, y = startOffset, length = 0;
      while(x < oldSize && y < newSize && oldData[x++] == newData[y++]) length++;

      if(length > outLength) {
        outLength = length;
        outOffset = offset;
        outSource = 0;
      }
    }

    for(unsigned offset = 0; offset < startOffset; offset++) {
      unsigned x = offset, y = startOffset, length = 0;
      while(x < newSize && y < newSize && newData[x++] == newData[y++]) length++;

      if(length > outLength) {
        outLength = length;
        outOffset = offset;
        outSource = 1;
      }
    }

    return outLength;
  }

  unsigned getDirect(unsigned offset) {
    unsigned length = 0;

    while(offset < newSize) {
      length += granularity;
      offset += granularity;

      unsigned lzLength, lzOffset;
      bool lzSource;
      lzLength = getLZ(offset, lzOffset, lzSource);
      if(lzLength >= granularity) break;
    }

    return length;
  }

  bool create(
    const char *modFilename,
    uint8_t *oldData_, unsigned oldSize_,
    uint8_t *newData_, unsigned newSize_
  ) {
    if(modFile.open(modFilename, file::mode::write) == false) return false;
    modChecksum = ~0;

    oldData = oldData_, oldSize = oldSize_;
    newData = newData_, newSize = newSize_;

    write('B');
    write('L');
    write('P');
    write('0');

    encode(oldSize);
    encode(newSize);
    encode(0);  //xmlSize

    oldOffset = newOffset = outOffset = 0;

    while(outOffset < newSize) {
      unsigned length;
      unsigned offset;
      bool source;

      length = getLZ(outOffset, offset, source);
      if(length >= granularity) {
printf("%.8x = L%10u %.8x %u\n", outOffset, length, offset, source);
        encode(((length - 1) << 1) | 1);
        signed relOffset;
        if(source == 0) {
          relOffset = offset - oldOffset;
          oldOffset = offset + length;
        } else {
          relOffset = offset - newOffset;
          newOffset = offset + length;
        }
        encode((abs(relOffset) << 2) | ((relOffset < 0) << 1) | source);
        outOffset += length;
      } else {
        length = getDirect(outOffset);
printf("%.8x = D%10u\n", outOffset, length);
        encode(((length - 1) << 1) | 0);
        for(unsigned x = 0; x < length; x++) {
          write(newData[outOffset++]);
        }
      }
    }

    uint32_t oldChecksum = crc32_calculate(oldData, oldSize);
    uint32_t newChecksum = crc32_calculate(newData, newSize);
    for(unsigned x = 0; x < 4; x++) write(oldChecksum >> (x << 3));
    for(unsigned x = 0; x < 4; x++) write(newChecksum >> (x << 3));
    uint32_t outChecksum = ~modChecksum;
    for(unsigned x = 0; x < 4; x++) write(outChecksum >> (x << 3));

    modFile.close();
  }
};

struct blpApply {
  uint8_t *oldData;
  unsigned oldSize;
  unsigned oldOffset;

  uint8_t *newData;
  unsigned newSize;
  unsigned newOffset;

  uint8_t *modData;
  unsigned modSize;
  unsigned modOffset;

  unsigned xmlSize;
  unsigned outOffset;

  uint8_t read() {
    return modData[modOffset++];
  }

  void write(uint8_t data) {
    if(outOffset < newSize) newData[outOffset++] = data;
  }

  uint64_t decode() {
    uint64_t offset = 0, shift = 1;
    while(true) {
      uint8_t x = read();
      offset += (x & 0x7f) * shift;
      if(x & 0x80) break;
      shift <<= 7;
      offset += shift;
    }
    return offset;
  }

  unsigned size(uint8_t *modData_, unsigned modSize_) {
    modData = modData_;
    modSize = modSize_;
    modOffset = 4;
    decode();
    return decode();
  }

  bool apply(
    uint8_t *modData_, unsigned modSize_,
    uint8_t *oldData_, unsigned oldSize_,
    uint8_t *newData_, unsigned newSize_
  ) {
    modData = modData_;
    modSize = modSize_;

    oldData = oldData_;
    oldSize = oldSize_;

    newData = newData_;
    newSize = newSize_;

    modOffset = oldOffset = newOffset = outOffset = 0;

    if(read() != 'B') return false;
    if(read() != 'L') return false;
    if(read() != 'P') return false;
    if(read() != '0') return false;

    if(decode() != oldSize) return false;
    if(decode() != newSize) return false;
    xmlSize = decode();
    modOffset += xmlSize;

    while(outOffset < newSize) {
      unsigned length = decode();
      bool mode = length & 1;
      length = (length >> 1) + 1;
      if(mode == 0) {
printf("%.8x = D%10u\n", outOffset, length);
        while(length--) write(read());
      } else {
        signed offset = decode();
        bool source = offset & 1;
        bool negative = (offset >> 1) & 1;
        offset >>= 2;
printf("%.8x = L%10u %.8x %u %u\n", outOffset, length, offset, negative, source);
        if(negative) offset = -offset;
        if(source == 0) {
          oldOffset += offset;
          while(length--) write(oldData[oldOffset++]);
        } else {
          newOffset += offset;
          while(length--) write(newData[newOffset++]);
        }
      }
    }
  }
};

int main(int argc, char **argv) {
  filemap modMap, oldMap, newMap;

  if(argc != 5) {
    printf("blip\n");
    printf("usage: blip (create | apply) patch-file old-file new-file\n");
    return 0;
  }

  if(!strcmp(argv[1], "create")) {
    oldMap.open(argv[3], filemap::mode::read);
    newMap.open(argv[4], filemap::mode::read);

    blpDelta patch;
    patch.create(argv[2], oldMap.data(), oldMap.size(), newMap.data(), newMap.size());

    oldMap.close();
    newMap.close();
  } else if(!strcmp(argv[1], "apply")) {
    modMap.open(argv[2], filemap::mode::read);
    oldMap.open(argv[3], filemap::mode::read);

    blpApply patch;
    unsigned newSize = patch.size(modMap.data(), modMap.size());

    file fp;
    fp.open(argv[4], file::mode::write);
    fp.seek(newSize);
    fp.close();

    newMap.open(argv[4], filemap::mode::readwrite);

    patch.apply(modMap.data(), modMap.size(), oldMap.data(), oldMap.size(), newMap.data(), newMap.size());

    modMap.close();
    oldMap.close();
    newMap.close();
  }

  return 0;
}
