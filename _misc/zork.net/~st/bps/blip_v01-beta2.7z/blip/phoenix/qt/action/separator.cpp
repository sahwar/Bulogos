void pSeparator::constructor() {
  qtAction = new QAction(0);
  qtAction->setSeparator(true);
}
