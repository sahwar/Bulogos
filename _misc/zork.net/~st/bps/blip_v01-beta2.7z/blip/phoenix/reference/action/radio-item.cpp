bool pRadioItem::checked() {
  return false;
}

void pRadioItem::setChecked() {
}

void pRadioItem::setGroup(const reference_array<RadioItem&> &group) {
}

void pRadioItem::setText(const string &text) {
}

void pRadioItem::constructor() {
}
