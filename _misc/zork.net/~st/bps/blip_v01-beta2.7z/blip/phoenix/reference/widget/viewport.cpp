uintptr_t pViewport::handle() {
  return 0;
}

void pViewport::constructor() {
}
