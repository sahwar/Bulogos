void pLineEdit::setEditable(bool editable) {
}

void pLineEdit::setText(const string &text) {
}

string pLineEdit::text() {
}

void pLineEdit::constructor() {
}
