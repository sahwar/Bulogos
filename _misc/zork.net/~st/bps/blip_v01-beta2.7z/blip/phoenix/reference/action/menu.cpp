void pMenu::append(Action &action) {
}

void pMenu::setText(const string &text) {
}

void pMenu::constructor() {
}
