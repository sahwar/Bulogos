void pTextEdit::setCursorPosition(unsigned position) {
}

void pTextEdit::setEditable(bool editable) {
}

void pTextEdit::setText(const string &text) {
}

void pTextEdit::setWordWrap(bool wordWrap) {
}

string pTextEdit::text() {
}

void pTextEdit::constructor() {
}
