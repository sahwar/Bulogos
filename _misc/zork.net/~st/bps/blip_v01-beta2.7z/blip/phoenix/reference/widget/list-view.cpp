void pListView::append(const lstring &text) {
}

void pListView::autoSizeColumns() {
}

bool pListView::checked(unsigned row) {
}

void pListView::modify(unsigned row, const lstring &text) {
}

void pListView::reset() {
}

bool pListView::selected() {
  return false;
}

unsigned pListView::selection() {
  return 0;
}

void pListView::setCheckable(bool checkable) {
}

void pListView::setChecked(unsigned row, bool checked) {
}

void pListView::setHeaderText(const lstring &text) {
}

void pListView::setHeaderVisible(bool visible) {
}

void pListView::setSelected(bool selected) {
}

void pListView::setSelection(unsigned row) {
}

void pListView::constructor() {
}
