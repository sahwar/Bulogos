void pFont::setBold(bool bold) {
}

void pFont::setFamily(const string &family) {
}

void pFont::setItalic(bool italic) {
}

void pFont::setSize(unsigned size) {
}

void pFont::setUnderline(bool underline) {
}

void pFont::constructor() {
}
