struct BlipPatch {
  enum : unsigned {
    SourceRead = 0,  //{ length }
    TargetRead = 1,  //{ length, data[] }
    SourceCopy = 2,  //{ length, offset }
    TargetCopy = 3,  //{ length, offset }
  };

  bool openSource(const string &sourceName);
  bool openTarget(const string &targetName);
  bool openChange(const string &changeName);

  bool openSource(const uint8_t *sourceData, unsigned sourceSize);
  bool openTarget(      uint8_t *targetData, unsigned targetSize);
  bool openChange(const uint8_t *changeData, unsigned changeSize);

  void close();
  bool apply();
  unsigned readTargetSize();
  string error;

private:
  uint64_t decode();
  uint8_t readSource(unsigned addr);
  uint8_t readTarget(unsigned addr);
  uint8_t readChange();
  void write(uint8_t data);

  filemap sourceFile;
  filemap targetFile;
  filemap changeFile;

  const uint8_t *sourceData;
  unsigned sourceSize;
  unsigned sourceRelativeOffset;

  uint8_t *targetData;
  unsigned targetSize;
  unsigned targetRelativeOffset;
  unsigned targetWriteOffset;

  const uint8_t *changeData;
  unsigned changeSize;
  unsigned changeReadOffset;
};

bool BlipPatch::openSource(const string &sourceName) {
  if(sourceFile.open(sourceName, filemap::mode::read) == false) return false;
  return openSource(sourceFile.data(), sourceFile.size());
}

bool BlipPatch::openSource(const uint8_t *sourceData, unsigned sourceSize) {
  this->sourceData = sourceData;
  this->sourceSize = sourceSize;
  return true;
}

bool BlipPatch::openTarget(const string &targetName) {
  unsigned targetSize = readTargetSize();
  file fp;
  if(fp.open(targetName, file::mode::write) == false) return false;
  fp.seek(targetSize);
  fp.close();

  if(targetFile.open(targetName, filemap::mode::readwrite) == false) return false;
  return openTarget(targetFile.data(), targetFile.size());
}

bool BlipPatch::openTarget(uint8_t *targetData, unsigned targetSize) {
  this->targetData = targetData;
  this->targetSize = targetSize;
  return true;
}

bool BlipPatch::openChange(const string &changeName) {
  if(changeFile.open(changeName, filemap::mode::read) == false) return false;
  return openChange(changeFile.data(), changeFile.size());
}

bool BlipPatch::openChange(const uint8_t *changeData, unsigned changeSize) {
  this->changeData = changeData;
  this->changeSize = changeSize;
  return true;
}

void BlipPatch::close() {
  if(sourceFile.open()) sourceFile.close();
  if(targetFile.open()) targetFile.close();
  if(changeFile.open()) changeFile.close();
}

bool BlipPatch::apply() {
  sourceRelativeOffset = 0;
  targetRelativeOffset = 0;
  targetWriteOffset = 0;
  changeReadOffset = 0;

  if(readChange() != 'b') { error = "Invalid blip header."; return false; }
  if(readChange() != 'l') { error = "Invalid blip header."; return false; }
  if(readChange() != 'i') { error = "Invalid blip header."; return false; }
  if(readChange() != 'p') { error = "Invalid blip header."; return false; }

  if(decode() != sourceSize) { error = "Invalid source file size."; return false; }
  if(decode() != targetSize) { error = "Invalid target file size."; return false; }
  unsigned metadataSize = decode();
  changeReadOffset += metadataSize;

  while(changeReadOffset < changeSize - 12) {
    unsigned length = decode();
    unsigned mode = length & 3;
    length = (length >> 2) + 1;

    if(mode == SourceRead) {
      while(length--) write(readSource(targetWriteOffset));
    } else if(mode == TargetRead) {
      while(length--) write(readChange());
    } else {  //(mode == SourceCopy || mode == TargetCopy)
      signed offset = decode();
      bool negative = offset & 1;
      offset >>= 1;
      if(negative) offset = -offset;
      if(mode == SourceCopy) {
        sourceRelativeOffset += offset;
        while(length--) write(readSource(sourceRelativeOffset++));
      } else {  //(mode == TargetCopy)
        targetRelativeOffset += offset;
        while(length--) write(readTarget(targetRelativeOffset++));
      }
    }
  }

  if(targetWriteOffset != targetSize) { error = "Bad target file size."; return false; }
  if(changeReadOffset != changeSize - 12) { error = "Invalid blip footer."; return false; }

  uint32_t sourceFooterChecksum = 0, targetFooterChecksum = 0, changeFooterChecksum = 0;
  for(unsigned n = 0; n < 32; n += 8) sourceFooterChecksum |= readChange() << n;
  for(unsigned n = 0; n < 32; n += 8) targetFooterChecksum |= readChange() << n;
  for(unsigned n = 0; n < 32; n += 8) changeFooterChecksum |= readChange() << n;

  uint32_t sourceChecksum = crc32_calculate(sourceData, sourceSize);
  uint32_t targetChecksum = crc32_calculate(targetData, targetSize);
  uint32_t changeChecksum = crc32_calculate(changeData, changeSize - 4);

  if(sourceChecksum != sourceFooterChecksum) { error = "Bad source checksum."; return false; }
  if(targetChecksum != targetFooterChecksum) { error = "Bad target checksum."; return false; }
  if(changeChecksum != changeFooterChecksum) { error = "Bad blip checksum."; return false; }

  error = "";
  return true;
}

unsigned BlipPatch::readTargetSize() {
  changeReadOffset = 0;
  if(readChange() != 'b') return false;
  if(readChange() != 'l') return false;
  if(readChange() != 'i') return false;
  if(readChange() != 'p') return false;
  unsigned sourceSize = decode();
  unsigned targetSize = decode();
  return targetSize;
}

uint64_t BlipPatch::decode() {
  uint64_t data = 0, shift = 1;
  while(true) {
    uint8_t x = readChange();
    data += (x & 0x7f) * shift;
    if(x & 0x80) break;
    shift <<= 7;
    data += shift;
  }
  return data;
}

uint8_t BlipPatch::readSource(unsigned addr) {
  return addr < sourceSize ? sourceData[addr] : 0x00;
}

uint8_t BlipPatch::readTarget(unsigned addr) {
  return addr < targetSize ? targetData[addr] : 0x00;
}

uint8_t BlipPatch::readChange() {
  return changeData[changeReadOffset++];
}

void BlipPatch::write(uint8_t data) {
  if(targetWriteOffset >= targetSize) return;
  targetData[targetWriteOffset++] = data;
}
