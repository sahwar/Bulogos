struct BlipDelta {
  enum : unsigned {
    OffsetSkip = 0,  //{ length }
    OutputCopy = 1,  //{ length }
    SourceCopy = 2,  //{ length, offset }
    TargetCopy = 3,  //{ length, offset }
  };

  enum : unsigned { Granularity = 8 };

  bool openSource(const string &sourceName);
  bool openTarget(const string &targetName);
  bool openChange(const string &changeName);

  bool openSource(const uint8_t *sourceData, unsigned sourceSize);
  bool openTarget(const uint8_t *targetData, unsigned targetSize);

  void close();
  void create();

private:
  unsigned getLZ(unsigned startOffset, unsigned &outputOffset, bool &outputSource);
  unsigned getDirect(unsigned offset);
  uint8_t readSource(unsigned addr);
  uint8_t readTarget(unsigned addr);
  void write(uint8_t data);
  void encode(uint64_t data);

  filemap sourceFile;
  filemap targetFile;
  file changeFile;

  const uint8_t *sourceData;
  unsigned sourceSize;
  unsigned sourceRelativeOffset;

  const uint8_t *targetData;
  unsigned targetSize;
  unsigned targetRelativeOffset;

  uint32_t changeChecksum;

  unsigned outputOffset;
  unsigned maximumSize;
};

bool BlipDelta::openSource(const string &sourceName) {
  if(sourceFile.open(sourceName, filemap::mode::read) == false) return false;
  return openSource(sourceFile.data(), sourceFile.size());
}

bool BlipDelta::openSource(const uint8_t *sourceData, unsigned sourceSize) {
  this->sourceData = sourceData;
  this->sourceSize = sourceSize;
  return true;
}

bool BlipDelta::openTarget(const string &targetName) {
  if(targetFile.open(targetName, filemap::mode::read) == false) return false;
  return openTarget(targetFile.data(), targetFile.size());
}

bool BlipDelta::openTarget(const uint8_t *targetData, unsigned targetSize) {
  this->targetData = targetData;
  this->targetSize = targetSize;
  return true;
}

bool BlipDelta::openChange(const string &changeName) {
  return changeFile.open(changeName, file::mode::write);
}

void BlipDelta::close() {
  if(sourceFile.open()) sourceFile.close();
  if(targetFile.open()) targetFile.close();
  if(changeFile.open()) changeFile.close();
}

void BlipDelta::create() {
  sourceRelativeOffset = 0;
  targetRelativeOffset = 0;
  changeChecksum = ~0;
  outputOffset = 0;
  maximumSize = max(sourceSize, targetSize);

  write('b');
  write('l');
  write('i');
  write('p');

  encode(sourceSize);
  encode(targetSize);
  encode(0);

  while(outputOffset < targetSize) {
    unsigned length;
    unsigned offset;
    bool source;

    length = getLZ(outputOffset, offset, source);
    if(length >= Granularity) {
      signed relativeOffset;
      if(source == 0) {
        encode(SourceCopy | ((length - 1) << 2));
        relativeOffset = offset - sourceRelativeOffset;
        sourceRelativeOffset = offset + length;
      } else {
        encode(TargetCopy | ((length - 1) << 2));
        relativeOffset = offset - targetRelativeOffset;
        targetRelativeOffset = offset + length;
      }
      encode((relativeOffset < 0) | (abs(relativeOffset) << 1));
      outputOffset += length;
    } else {
      length = getDirect(outputOffset);
      encode(OutputCopy | ((length - 1) << 2));
      for(unsigned n = 0; n < length; n++) {
        write(targetData[outputOffset++]);
      }
    }
  }

  uint32_t sourceChecksum = crc32_calculate(sourceData, sourceSize);
  uint32_t targetChecksum = crc32_calculate(targetData, targetSize);

  for(unsigned n = 0; n < 32; n += 8) write(sourceChecksum >> n);
  for(unsigned n = 0; n < 32; n += 8) write(targetChecksum >> n);
  uint32_t checksum = ~changeChecksum;
  for(unsigned n = 0; n < 32; n += 8) write(checksum >> n);
}

unsigned BlipDelta::getLZ(unsigned startOffset, unsigned &outputOffset, bool &outputSource) {
  unsigned outputLength = 0;

  for(unsigned offset = 0; offset < sourceSize; offset++) {
    unsigned x = offset, y = startOffset, length = 0;
    while(x < sourceSize && y < targetSize && sourceData[x++] == targetData[y++]) length++;

    if(length > outputLength) {
      outputLength = length;
      outputOffset = offset;
      outputSource = 0;
    }
  }

  for(unsigned offset = 0; offset < startOffset; offset++) {
    unsigned x = offset, y = startOffset, length = 0;
    while(x < sourceSize && y < targetSize && targetData[x++] == targetData[y++]) length++;

    if(length > outputLength) {
      outputLength = length;
      outputOffset = offset;
      outputSource = 1;
    }
  }

  return outputLength;
}

unsigned BlipDelta::getDirect(unsigned offset) {
  unsigned length = 0;

  while(offset < targetSize) {
    length += Granularity;
    offset += Granularity;

    unsigned lzLength;
    unsigned lzOffset;
    bool lzSource;

    lzLength = getLZ(offset, lzOffset, lzSource);
    if(lzLength >= Granularity) break;
  }

  return length;
}

uint8_t BlipDelta::readSource(unsigned addr) {
  return addr < sourceSize ? sourceData[addr] : 0x00;
}

uint8_t BlipDelta::readTarget(unsigned addr) {
  return addr < targetSize ? targetData[addr] : 0x00;
}

void BlipDelta::write(uint8_t data) {
  changeFile.write(data);
  changeChecksum = crc32_adjust(changeChecksum, data);
}

void BlipDelta::encode(uint64_t data) {
  while(true) {
    uint64_t x = data & 0x7f;
    data >>= 7;
    if(data == 0) {
      write(0x80 | x);
      break;
    }
    write(x);
    data--;
  }
}
