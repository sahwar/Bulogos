struct BlipLinear {
  enum : unsigned {
    OffsetSkip = 0,  //{ length }
    OutputCopy = 1,  //{ length }
    SourceCopy = 2,  //{ length, offset }
    TargetCopy = 3,  //{ length, offset }
  };

  bool openSource(const string &sourceName);
  bool openTarget(const string &targetName);
  bool openChange(const string &changeName);

  bool openSource(const uint8_t *sourceData, unsigned sourceSize);
  bool openTarget(const uint8_t *targetData, unsigned targetSize);

  void close();
  void create();

private:
  unsigned sameLength();
  unsigned diffLength();
  unsigned rleLength(unsigned outputOffset);
  uint8_t readSource(unsigned addr);
  uint8_t readTarget(unsigned addr);
  void write(uint8_t data);
  void encode(uint64_t data);

  filemap sourceFile;
  filemap targetFile;
  file changeFile;

  const uint8_t *sourceData;
  unsigned sourceSize;
  unsigned sourceRelativeOffset;

  const uint8_t *targetData;
  unsigned targetSize;
  unsigned targetRelativeOffset;

  uint32_t changeChecksum;

  unsigned outputOffset;
  unsigned minimumSize;
  unsigned maximumSize;
};

bool BlipLinear::openSource(const string &sourceName) {
  if(sourceFile.open(sourceName, filemap::mode::read) == false) return false;
  return openSource(sourceFile.data(), sourceFile.size());
}

bool BlipLinear::openSource(const uint8_t *sourceData, unsigned sourceSize) {
  this->sourceData = sourceData;
  this->sourceSize = sourceSize;
  return true;
}

bool BlipLinear::openTarget(const string &targetName) {
  if(targetFile.open(targetName, filemap::mode::read) == false) return false;
  return openTarget(targetFile.data(), targetFile.size());
}

bool BlipLinear::openTarget(const uint8_t *targetData, unsigned targetSize) {
  this->targetData = targetData;
  this->targetSize = targetSize;
  return true;
}

bool BlipLinear::openChange(const string &changeName) {
  return changeFile.open(changeName, file::mode::write);
}

void BlipLinear::close() {
  if(sourceFile.open()) sourceFile.close();
  if(targetFile.open()) targetFile.close();
  if(changeFile.open()) changeFile.close();
}

void BlipLinear::create() {
  sourceRelativeOffset = 0;
  targetRelativeOffset = 0;
  changeChecksum = ~0;
  outputOffset = 0;

  minimumSize = min(sourceSize, targetSize);
  maximumSize = max(sourceSize, targetSize);

  write('b');
  write('l');
  write('i');
  write('p');

  encode(sourceSize);
  encode(targetSize);
  encode(0);

  //copy sourceData to targetData; so that we can use OffsetSkip instead of SourceCopy
  encode(SourceCopy | ((minimumSize - 1) << 2));
  encode(0);

  while(outputOffset < targetSize) {
    unsigned sameLength = this->sameLength();
    if(sameLength > 0) {
      encode(OffsetSkip | ((sameLength - 1) << 2));
      outputOffset += sameLength;
      continue;
    }

    unsigned diffLength = this->diffLength();
    if(diffLength > 0) {
      unsigned rleLength = this->rleLength(outputOffset);
      if(rleLength > 10) {
        encode(OutputCopy | ((1 - 1) << 2));
        write(readTarget(outputOffset));
        encode(TargetCopy | ((rleLength - 2) << 2));
        unsigned relativeOffset = outputOffset - targetRelativeOffset;
        encode(relativeOffset << 1);
        outputOffset += rleLength;
        targetRelativeOffset = outputOffset - 1;
      } else {
        encode(OutputCopy | ((diffLength - 1) << 2));
        for(unsigned n = 0; n < diffLength; n++) write(readTarget(outputOffset + n));
        outputOffset += diffLength;
      }
      continue;
    }
  }

  uint32_t sourceChecksum = crc32_calculate(sourceData, sourceSize);
  uint32_t targetChecksum = crc32_calculate(targetData, targetSize);

  for(unsigned n = 0; n < 32; n += 8) write(sourceChecksum >> n);
  for(unsigned n = 0; n < 32; n += 8) write(targetChecksum >> n);
  unsigned checksum = ~changeChecksum;
  for(unsigned n = 0; n < 32; n += 8) write(checksum >> n);
}

unsigned BlipLinear::sameLength() {
  unsigned length = 0;
  for(unsigned n = outputOffset; n < targetSize; n++) {
    if(readSource(n) != readTarget(n)) break;
    length++;
  }
  return length;
}

unsigned BlipLinear::diffLength() {
  unsigned length = 0;
  for(unsigned n = outputOffset; n < targetSize; n++) {
    if(readSource(n) == readTarget(n)) break;
    if(length && rleLength(n) > 10) break;
    length++;
  }
  return length;
}

unsigned BlipLinear::rleLength(unsigned outputOffset) {
  unsigned length = 1, data = readTarget(outputOffset);
  for(unsigned n = outputOffset + 1; n < targetSize; n++) {
    if(readTarget(n) != data) break;
    length++;
  }
  return length;
}

uint8_t BlipLinear::readSource(unsigned addr) {
  return addr < sourceSize ? sourceData[addr] : 0x00;
}

uint8_t BlipLinear::readTarget(unsigned addr) {
  return addr < targetSize ? targetData[addr] : 0x00;
}

void BlipLinear::write(uint8_t data) {
  changeFile.write(data);
  changeChecksum = crc32_adjust(changeChecksum, data);
}

void BlipLinear::encode(uint64_t data) {
  while(true) {
    uint64_t x = data & 0x7f;
    data >>= 7;
    if(data == 0) {
      write(0x80 | x);
      break;
    }
    write(x);
    data--;
  }
}
