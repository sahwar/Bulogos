void pItem::setText(const string &text) {
}

void pItem::constructor() {
}
