bool pWidget::enabled() {
  return false;
}

void pWidget::setEnabled(bool enabled) {
}

void pWidget::setFocused() {
}

void pWidget::setFont(Font &font) {
}

void pWidget::setGeometry(const Geometry &geometry) {
}

void pWidget::setVisible(bool visible) {
}

void pWidget::constructor() {
}
