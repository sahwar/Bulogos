bool pCheckItem::checked() {
  return false;
}

void pCheckItem::setChecked(bool checked) {
}

void pCheckItem::setText(const string &text) {
}

void pCheckItem::constructor() {
}
