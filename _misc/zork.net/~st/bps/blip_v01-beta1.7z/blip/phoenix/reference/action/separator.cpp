void pSeparator::constructor() {
}
