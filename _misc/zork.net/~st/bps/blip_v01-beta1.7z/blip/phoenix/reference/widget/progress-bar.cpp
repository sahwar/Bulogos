void pProgressBar::setPosition(unsigned position) {
}

void pProgressBar::constructor() {
}
