"""
Exceptions raised while reading or applying UPS patches.
"""
# For copyright and licensing information, see the file COPYING.

class UPSException(Exception):
	pass

class PatchFormatException(UPSException):
	pass

class UnrecognisedFile(UPSException):
	def __init__(self, actualSize, actualCRC, file1Size, file1CRC, file2Size, 
			file2CRC):

		self.actualSize	= actualSize
		self.actualCRC	= actualCRC
		self.file1Size	= file1Size
		self.file1CRC	= file1CRC
		self.file2Size	= file2Size
		self.file2CRC	= file2CRC

	def __str__(self):
		return ("Source file is %d bytes and has CRC32: %08X, expected either "
				"%d bytes and CRC32: %08X or %d bytes and CRC32: %08X" % (
					self.actualSize, self.actualCRC, self.file1Size,
					self.file1CRC, self.file2Size, self.file2CRC))
