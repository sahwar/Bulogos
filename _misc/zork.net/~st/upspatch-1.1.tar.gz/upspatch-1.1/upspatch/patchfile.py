"""
The code used for parsing and serializing UPS files.
"""
# For copyright and licensing information, see the file COPYING.
import sys
import re
from array import array
from struct import unpack, pack
from binascii import crc32

from upspatch.util import _callWithMappedFile, encode_vli, decode_vli, \
		CRCTrackingOutputFile
from upspatch.hunks import CopyHunk, PatchHunk
from upspatch.exceptions import PatchFormatException, UnrecognisedFile

UPS_MAGIC = "UPS1"

class PatchFile(object):
	"""
	Represents the contents of a UPS patch file.
	"""

	VLI_END_RE = re.compile("[\x80-\xff]")
	PATCH_HUNK_END_RE = re.compile("\0")

	def __init__(self, patchFileName):
		self.patchFileCRC = None
		self.expectedFile1Size = None
		self.expectedFile1CRC = None
		self.expectedFile2Size = None
		self.expectedFile2CRC = None
		self.hunks = []

		_callWithMappedFile(patchFileName, self._init_from_patchfile)

	def __repr__(self):
		return ("<UPSPatch between a %d-byte file (CRC32: %08X) and a %d-byte "
				"file (CRC32: %08X) in %d hunks>" % (self.expectedFile1Size,
					self.expectedFile1CRC, self.expectedFile2Size, 
					self.expectedFile2CRC, len(self.hunks)))

	# Reading a patch in from disk

	def _read_until_re(self, mappedFile, re):
		"""
		Reads a string of bytes from a mmap object until one matches re.
		"""
		start = mappedFile.tell()
		match = re.search(mappedFile, start)
		if not match:
			raise PatchFormatException("Patch file doesn't have any bytes "
					"matching %r after offset 0x%08X" % (re.pattern, start))

		res = mappedFile.read(match.end()-start)
		return res

	def _read_vli(self, mappedFile):
		vliBytes = self._read_until_re(mappedFile, self.VLI_END_RE)
		return decode_vli(vliBytes)

	def _check_patch_file(self, patchFileBytes):
		# The easiest sanity-check is the file signature.
		patchSignature = patchFileBytes[:4]
		if patchSignature != UPS_MAGIC:
			raise PatchFormatException("Patch signature is %r, not 'UPS1'"
					% patchSignature)

		# The second-easiest check is the patch CRC, since we have the whole
		# patch in memory anyway.
		# This CRC calculation might cause unnecessary disk thrashing if the
		# patch is too large to keep entirely in memory, but that seems
		# unlikely.
		actualPatchCRC = crc32(patchFileBytes[0:-4])
		expectedPatchCRC = unpack("<i",patchFileBytes[-4:])[0]
		if expectedPatchCRC != actualPatchCRC:
			raise PatchFormatException("Patch is corrupted: expected CRC "
					"%08X, found CRC %08X" % (expectedPatchCRC, 
						actualPatchCRC))

		self.patchCRC = actualPatchCRC

	def _read_hunks(self, mappedFile, limit):
		while mappedFile.tell() < limit:
			self.hunks.append(CopyHunk(self._read_vli(mappedFile)))

			patchBytes = self._read_until_re(mappedFile, 
					self.PATCH_HUNK_END_RE)
			self.hunks.append(PatchHunk(patchBytes))

	def _init_from_patchfile(self, patchFileBytes):
		self._check_patch_file(patchFileBytes)

		# All the interesting data in the file is between the signature
		# (4 bytes at the beginning) and the CRCs (12 bytes at the
		# end), so all our file-reading should occur between those two
		# extremes.
		patchFileBytes.seek(4)
		fileLimit = patchFileBytes.size() - 12

		# Extract the expected file sizes
		self.expectedFile1Size = self._read_vli(patchFileBytes)
		self.expectedFile2Size = self._read_vli(patchFileBytes)

		# Extract the hunks
		self._read_hunks(patchFileBytes, fileLimit)

		# By now, we should have read exactly everything up to the CRCs
		# at the end.
		if patchFileBytes.tell() != fileLimit:
			raise PatchFormatException()

		# At the end of the file come the expected CRCs.
		self.expectedFile1CRC = unpack("<i", patchFileBytes.read(4))[0]
		self.expectedFile2CRC = unpack("<i", patchFileBytes.read(4))[0]

	# Saving this patch to disk

	def save_to_file(self, filename):
		"""
		Writes this patch out to the given file in UPS format.
		"""
		patchFile = CRCTrackingOutputFile(filename)

		patchFile.write(UPS_MAGIC)

		patchFile.write(encode_vli(self.expectedFile1Size))
		patchFile.write(encode_vli(self.expectedFile2Size))

		for hunk in self.hunks:
			patchFile.write(str(hunk))

		patchFile.write(pack("<i", self.expectedFile1CRC))
		patchFile.write(pack("<i", self.expectedFile2CRC))

		# Check that we haven't corrupted the patch between reading it in and
		# writing it out.
		if self.patchCRC is not None:
			assert patchFile.crc == self.patchCRC

		patchFile.write(pack("<i", patchFile.crc))
		patchFile.close()

	# Applying this patch to an existing file
	
	def _pick_new_file_data(self, oldFileBytes):
		oldFileCRC = crc32(oldFileBytes)
	
		if (oldFileCRC == self.expectedFile1CRC 
				and oldFileBytes.size() == self.expectedFile1Size):
			newFileSize = self.expectedFile2Size
			newFileCRC = self.expectedFile2CRC
		elif (oldFileCRC == self.expectedFile2CRC  
				and oldFileBytes.size() == self.expectedFile2Size):
			newFileSize = self.expectedFile1Size
			newFileCRC = self.expectedFile1CRC
		else:
			raise UnrecognisedFile(oldFileBytes.size(), oldFileCRC,
					self.expectedFile1Size, self.expectedFile1CRC,
					self.expectedFile2Size, self.expectedFile2CRC)

		return (newFileSize, newFileCRC)

	def _apply_with_old_and_new_file(self, oldFileBytes, newFile, newFileSize):

		# Apply all our patch hunks
		for hunk in self.hunks:
			hunk.apply(oldFileBytes, newFile)

			# If we're patching a longer file into a shorter one, we don't need
			# to bother carefully zeroing out all the extra data.
			if newFile.tell() >= newFileSize:
				break
		else:
			# There's an implicit copy hunk at the end of the file, if the old
			# file length and the expected length are greater than the current
			# new file length.
			if len(oldFileBytes) > newFile.tell():
				newFile.write(oldFileBytes[newFile.tell():len(oldFileBytes)+1])

	def _apply_with_old_file(self, oldFileBytes, newFileName):
		newFileSize, expectedNewFileCRC = self._pick_new_file_data(
				oldFileBytes)

		newFile = CRCTrackingOutputFile(newFileName, newFileSize)
		try:
			self._apply_with_old_and_new_file(oldFileBytes, newFile, 
					newFileSize)
			assert newFile.tell() == newFileSize
			assert newFile.crc == expectedNewFileCRC
		finally:
			newFile.close()

	def apply(self, oldFileName, newFileName):
		"""
		Applies this patch to oldFileName, producing newFileName.

		oldFileName must be the path to an existing file, which is a copy of
		one of the two files used to create this patch.

		newFileName will be created with the contents of the other of the two
		files used to create this patch.

		If oldFileName is not one of the two files used to create this patch,
		UnrecognisedFile will be raised.
		"""
		_callWithMappedFile(oldFileName, self._apply_with_old_file, newFileName)
