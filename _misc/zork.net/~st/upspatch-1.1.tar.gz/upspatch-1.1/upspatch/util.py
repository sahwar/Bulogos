"""
Utility methods used when reading UPS patches.
"""
# For copyright and licensing information, see the file COPYING.
from mmap import mmap, ACCESS_READ, error as mmapError
from array import array
from binascii import crc32

def _callWithMappedFile(filename, callable, *args, **kwargs):
	"""
	Open a file, mmap it, and pass the mmap object to the callable.

	Takes care of determining the size to mmap, and exception-safe cleanup.
	"""
	fileHandle = open(filename, 'rb')
	try:
		fileHandle.seek(0,2)
		fileSize = fileHandle.tell()
		fileHandle.seek(0)

		mappedHandle = mmap(fileHandle.fileno(), fileSize, access=ACCESS_READ)
		try:
			callable(mappedHandle, *args, **kwargs)
		finally:
			mappedHandle.close()
	finally:
		fileHandle.close()

def encode_vli(number):
	"""
	Encodes a number as a variable-length string.
	"""
	assert type(number) in (int, long)
	res = array('B')
	byte = 0

	while True:
		byte = number & 0x7f
		number >>= 7

		#print number
		assert number >= 0, 'number is %d' % number

		if number == 0: # no more bits!
			res.append(byte | 0x80)
			break

		res.append(byte)

		# The effect here is that part of the integer is encoded in its
		# position of a byte as well as its bits, so that you can't pad the
		# string with bytes that don't affect the output.
		number -= 1

	return res.tostring()

def decode_vli(string):
	"""
	Decodes a variable-length-integer from a string into a number.
	"""
	# A VLI is an arbitrarily-long string of bytes, terminated by a byte with
	# the high bit (0x80) set. We assume the caller has already grabbed
	# a string of the correct length.
	assert string[-1] > "\x7f"

	res = 0
	shift = 1

	for byte in string:
		res += (ord(byte) & 0x7f) * shift
		if byte > '\x7f':
			break
		shift <<= 7
		res += shift

	return res


class CRCTrackingOutputFile(file):
	"""
	A write-only file that keeps track of the CRC32 of its contents.
	"""

	def __init__(self, filename, expectedSize=None):
		super(CRCTrackingOutputFile, self).__init__(filename, mode='wb')
		self.crc = 0

		self.expectedSize = expectedSize

	def write(self, bytes):
		# If we have an expected size, never write past that point.
		if self.expectedSize is not None:
			if self.tell() == self.expectedSize:
				return
			if self.tell() + len(bytes) > self.expectedSize:
				bytes = bytes[:self.expectedSize - self.tell()]

		super(CRCTrackingOutputFile, self).write(bytes)
		self.crc = crc32(bytes, self.crc)

	def seek(self, whither, whence=0):
		raise NotImplementedError()


