"""
A library for working with UPS patch files.

UPS is a binary-patching format designed to represent changes (not insertions
or deletions) to a file, such as are commonly used to distribute
fan-translations of older videogames. It is designed to replace the more
limited IPS format, which became popular for the same purpose.
"""
# For copyright and licensing information, see the file COPYING.

from upspatch.patchfile import PatchFile as _PatchFile
from upspatch.exceptions import UPSException, PatchFormatException, \
		UnrecognisedFile

def patchFromFile(filename):
	"""
	Read the given patch-file into a patch object.
	"""
	return _PatchFile(filename)
