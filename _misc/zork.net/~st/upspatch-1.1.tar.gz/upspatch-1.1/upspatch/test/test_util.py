#!/usr/bin/env python
# For copyright and licensing information, see the file COPYING.
import unittest

from upspatch import util


class TestVLICoding(unittest.TestCase):

	def test_encode_vli(self):
		self.assertEqual(util.encode_vli(0), "\x80")
		self.assertEqual(util.encode_vli(2097152), "\x00\x7f\xfe")

	def test_decode_vli(self):
		self.assertEqual(util.decode_vli("\x80"), 0)
		self.assertEqual(util.decode_vli("\x00\x7f\xfe"), 2097152)


if __name__ == '__main__':
	unittest.main()
