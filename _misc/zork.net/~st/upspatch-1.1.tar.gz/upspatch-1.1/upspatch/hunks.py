"""
Classes to represent individual patch hunks in a UPS file.
"""
# For copyright and licensing information, see the file COPYING.
from array import array
from upspatch.util import encode_vli

class AbstractHunk(object):

	def __init__(self, handle):
		raise NotImplementedError()

	def __getitem__(self, key):
		raise NotImplementedError()

	def __len__(self):
		raise NotImplementedError()

	def apply(self, oldFileBytes, newFile):
		start = newFile.tell()
		end = start + len(self)
		oldFileSize = oldFileBytes.size()

		if start == end:
			return
		elif oldFileSize <= start:
			# We're copying hypothetical NUL bytes past the end of the old
			# file.
			self._apply_after_src_end(newFile)
		elif start < oldFileSize < end:
			# This copy hunk crosses the end of the file.
			self[:oldFileSize - start].apply(oldFileBytes, newFile)
			self[oldFileSize - start:].apply(oldFileBytes, newFile)
		else: # end <= oldFileBytes.size()
			self._apply_before_src_end(oldFileBytes, newFile)


class CopyHunk(AbstractHunk):

	def __init__(self, copyLength):
		self.copyLength = copyLength

	def __getitem__(self, key):
		assert isinstance(key, slice)

		assert key.step is None
		start = key.start or 0
		stop = key.stop or self.copyLength

		return CopyHunk(stop - start)

	def __len__(self):
		return self.copyLength

	def __repr__(self):
		return "<CopyHunk of %d bytes>" % self.copyLength

	def __str__(self):
		return encode_vli(self.copyLength)

	def _apply_after_src_end(self, newFile):
		newFile.write("\0" * self.copyLength)

	def _apply_before_src_end(self, oldFileBytes, newFile):
		start = newFile.tell()
		newFile.write(oldFileBytes[start:start + self.copyLength])


class PatchHunk(AbstractHunk):

	def __init__(self, patchBytes):
		self.patchBytes = array('B', patchBytes)

	def __getitem__(self, key):
		res = PatchHunk("")
		res.patchBytes = self.patchBytes[key]
		return res

	def __len__(self):
		return len(self.patchBytes)

	def __repr__(self):
		return "<PatchHunk of %d bytes>" % len(self)

	def __str__(self):
		return self.patchBytes.tostring()

	def _apply_after_src_end(self, newFile):
		newFile.write(self.patchBytes.tostring())

	def _apply_before_src_end(self, oldFileBytes, newFile):
		start = newFile.tell()
		data = array('B', oldFileBytes[start:start+len(self.patchBytes)])
		for i, patchByte in enumerate(self.patchBytes):
			data[i] ^= patchByte
		newFile.write(data.tostring())

