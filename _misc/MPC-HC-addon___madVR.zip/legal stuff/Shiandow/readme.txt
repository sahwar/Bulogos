You can extract the HLSL files into the root of this folder and change them.
madVR will then recompile and use the HLSL files instead of the precompiled
shaders stored in "madVR.ax".
