#xs comment -*-coding: iso-8859-5;-*-
Use Bulgarian locale and keyboard and Cyrillic fonts in X Window.
END
�����������, ��������� ����������� � ���������� �� X Window.
END


print <<'EOF';
# Setup the Cyrillic
test ${HOME}/.xcyrillic && . ${HOME}/.xcyrillic

# Check if the user suplies startup commands by him/herself
xsession=~/.xsession
if sed '1,/^. ---- bulgarian-env end/d' $xsession | grep -qs '^ *[^#]'; then
    exec sh -c  "sed '1,/^. ---- bulgarian-env end/d' $xsession | bash"
fi

# If he/she doesn't, then emulate the default action.

# This code is for Debian.
if [ -x /usr/bin/x-window-manager ]; then
    realstartup=x-window-manager
elif [ -x /usr/bin/x-terminal-emulator ]; then
    realstartup=x-terminal-emulator
# This code is for Red Hat and Mandrake
elif [ -x /etc/X11/xinit/Xclients ]; then
    exec /etc/X11/xinit/Xclients
# This code is for Slackware
elif [ -x /etc/X11/xinit/xinitrc ]; then
    exec /etc/X11/xinit/xinitrc
else
# Fatal error
    echo -n "Xsession: unable to start X session; "
    echo "no window managers, and no terminal emulators found."
    echo " Aborting."
    exit 1
fi

# Again for Debian.
startssh=/usr/bin/ssh-agent
if [ "$startssh" ]; then
  exec $sshagent $realstartup
else
  exec $realstartup
fi

EOF
