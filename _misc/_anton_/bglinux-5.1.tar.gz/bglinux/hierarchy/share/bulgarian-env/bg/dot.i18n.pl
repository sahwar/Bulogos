# s comment -*-coding: iso-8859-5;-*-
Cyrillic localization.  This setting is for Mandrake Linux only.
END
Cyrillic localization.  This setting is for Mandrake Linux only.
END


$LOCALE2 = ${LOCALE};
$LOCALE2 =~ s/\..*//;

$LOCALE3 = ${LOCALE};
$LOCALE3 =~ s/_.*//;

print "LANG=${LOCALE}\n";
print "LINGUAS=${LOCALE2}:${LOCALE3}:en_GB:en\n";
print "LANGUAGE=${LOCALE3}\n";
print "LC_ALL=${LOCALE}\n";
