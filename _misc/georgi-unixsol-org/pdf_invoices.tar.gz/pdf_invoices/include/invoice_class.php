<?php
# Class that generates invoices in PDF and HTML format
#
# Copyright (C) 2003 Unix Solutions Ltd.
# Written by Georgi Chorbadzhiyski
# All rights reserved.
#
# Redistribution and use of this script, with or without modification, is
# permitted provided that the following conditions are met:
#
# 1. Redistributions of this script must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#
#  THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
#  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
#  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO
#  EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
#  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
#  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
#  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
#  OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
#  ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# $Id: invoice_class.php,v 1.4 2003/11/27 18:09:49 gf Exp $
#
	define("FPDF_FONTPATH","include/pdf_fonts/");
	include("fpdf.php");
	include("num2bgtext.php");

class Invoice extends FPDF {
	var $sum=0; /* Sum of invoice items */
	var $vat=0; /* VAT of invoice items */
	var $total=0; /* Sum + VAT */
	var $total_text=""; /* Text representation of total */
	var $idata=""; /* Invoice data, initialized by InitInvoice() */

	var $html_show_start=1; /* Show <html><head></head><body> */
	var $html_show_end=1; /* Show </body></html> */
	var $htmlbuffer=""; /* Variable holding generated HTML */

	var $client_fields = array("���","�������","����","�����","���","�����", "������� ������", "��� ������", "������ ���");

	/* Internal variables */
	var $pdfinitialized=0;
	var $htmlinitialized=0;
	var $mode = 0; /* 0 - PDF mode  1 - HTML mode */

	var $dds_percent = 20;

	function InitInvoice($idata) {
		$this->idata = $idata;
	}

	function Output($file='',$download=false) {
		if ($this->mode == 0) {
			parent::Output($file, $download);
		} else {
			print $this->htmlbuffer;
		}
	}

/*	$original == 0  - Generate both
	$original == 1  - Generate original only
	$original == 2  - Generate not-original only
*/
	function CreatePDF($original=0) {
		/* �� ���������� ������ ���� "��-��������" */
		if ($this->idata["type"] == 2)
			$original = 2;

		$this->mode = 0;
		if (!$this->pdfinitialized) {
			$this->Open();
			$this->AddFont("ArialCyr","","arial.php");
			$this->AddFont("ArialCyr","B","arialb.php");
			$this->SetFont("ArialCyr","",10);
			$this->pdfinitialized = 1;
		}
		$org = 1;
		if ($original == 2)
			$org = 0;
		$this->AddPage();
		$this->pdf_AddHeader($org);
		$this->pdf_AddBuyerAndSeller();
		$this->pdf_AddProducts();
		$this->pdf_AddTotals();
		$this->pdf_AddFooter();
		/* Small recursion */
		if ($original == 0) {
			$this->CreatePDF(2);
		}
	}

	function CreateHTML($original=0, $show_start=1, $show_end=1) {
		/* �� ���������� ������ ���� "��-��������" */
		if ($this->idata["type"] == 2)
			$original = 2;

		$this->mode = 1;
		@ob_end_flush();
		ob_start();
		$this->html_show_start = $show_start;
		$this->html_show_end = $show_end;
		if ($original == 0) {
			$this->html_AddHeader(1);
			$this->html_AddBuyerAndSeller();
			$this->html_AddProducts();
			$this->html_AddTotals();
			$this->html_show_end = 0;
			$this->html_AddFooter();
?>
<p style="page-break-after:always;"></p>
<?
			$this->html_show_start = 0;
			$this->html_AddHeader(0);
			$this->html_AddBuyerAndSeller();
			$this->html_AddProducts();
			$this->html_AddTotals();
			$this->html_AddFooter();
			$this->html_show_start = $show_start;
			$this->html_show_end = $show_end;
		} else {
			if ($original == 2)
				$original = 0;
			$this->html_AddHeader($original);
			$this->html_AddBuyerAndSeller();
			$this->html_AddProducts();
			$this->html_AddTotals();
			$this->html_AddFooter();
		}
		$this->htmlbuffer = ob_get_contents();
		ob_end_clean();
		ob_start();
	}

/* PDF FUNCTIONS */
	function pdf_AddHeader($original=1) {
		$this->SetTitle("������� ".$this->idata['num']." �� ".$this->idata['date']);
		$this->SetCreator("UnixSol.org");
		$this->SetSubject("������� ".$this->idata['num']." �� ".$this->idata['date']);
		$this->SetDisplayMode("real","continuous");

		$this->Cell(105,5,"��� �� ���������",1,0);
		$this->Cell(60,5,"�������� N:",1,0,"R");
		$this->Cell(0,5,"�� ����",1,1,"C");

		$orig = "";
		if ($original)
			$orig = " (��������)";

		$this->SetFont("","B",16);
		if (!isset($this->idata["dds"]))
			$this->idata["dds"] = true;
		switch ($this->idata["type"]) {
			case 0:
				$this->Cell(105,7,"������� �������".$orig,1,0);
				break;
			case 1:
				$this->Cell(105,7,"��������� �������".$orig,1,0);
				$this->idata["dds"] = false;
				break;
			case 2:
				$this->Cell(105,7,"�������� �������".$orig,1,0);
				break;
		}

		$this->SetFontSize(12);
		$this->Cell(60,7,$this->idata['num'],1,0,"R");
		$this->Cell(0,7,$this->idata['date'],1,1,"C");
		$this->SetFont("","",10);

		$this->Ln(5);
	}

	function pdf_AddBuyerAndSeller() {
		$this->Cell(105,5,"�������",1,0);
		$this->Cell(0,5,"��������",1,1);

		$this->SetFont("","B",14);
		$this->Cell(105,7,$this->idata['buyer'],1,0,"C");
		$this->Cell(0,7,$this->idata['seller'],1,1,"C");
		$this->SetFont("","",10);

		foreach ($this->client_fields as $i => $field) {
			$this->Cell(30,5,$field,"L");
			$bdata = "";
			$sdata = "";
			if (isset($this->idata['buyer_data'][$i]))
				$bdata = $this->idata['buyer_data'][$i];
			if (isset($this->idata['seller_data'][$i]))
				$sdata = $this->idata['seller_data'][$i];
			$this->Cell(75,5,$bdata,"R");
			$this->Cell(30,5,$field,"L");
			$this->Cell(0 ,5,$sdata,"R",1);
		}
		$this->Ln(0);
		$this->Cell(0 ,5,"","T",1,1);
	}

	function pdf_AddProducts() {
		$this->SetFont("","B",10);
		$this->Cell(10,5,"N:",1,0,"C");
		$this->Cell(95,5,"������������",1,0,"C");
		$this->Cell(25,5,"�����.",1,0,"C");
		$this->Cell(25,5,"��. ����",1,0,"C");
		$this->Cell(0,5,"���� ����",1,1,"C");
		$this->SetFont("","",10);

		$this->sum = 0;
		foreach ($this->idata['products'] as $i => $product) {
			$this->Cell(10,5,$i+1,1,0,"C");
			$this->Cell(95,5,$product[0],1,0);
			$this->Cell(25,5,$product[1],1,0,"C");
			$this->Cell(25,5,$product[2],1,0,"C");
			$this->Cell(0,5,$product[1]*$product[2],1,1,"C");
			$this->sum += $product[1]*$product[2];
		}
		$this->vat = $this->sum * ($this->dds_percent / 100);
		if ($this->idata["dds"])
			$this->total = $this->sum + $this->vat;
		else
			$this->total = $this->sum;

		$this->total_text = number2lv($this->total);

		$this->Ln(5);
	}

	function pdf_AddTotals() {
		$this->SetFont("","B",10);
		$this->Cell(105,5,"������","TRL");
		$this->Cell(50,5,"��-� �� ��������","T");
		$this->SetFont("","B",11);
		$this->Cell(0,5,$this->sum,"TR",1,"C");
		$this->SetFont("","",10);

		$this->Cell(105,5,$this->total_text,"LR");
		if ($this->idata["dds"]) {
			$this->SetFont("","B",10);
			$this->Cell(50,5,"��� {$this->dds_percent}%");
			$this->SetFont("","B",11);
			$this->Cell(0,5,$this->vat,"R",1,"C");
			$this->SetFont("","",10);
		} else {
			$this->Cell(0,5,"","R",1);
		}

		$this->SetFont("","B",10);
		$this->Cell(105,5,"","LRB");
		$this->Cell(50,5,"���� ��������","B");
		$this->SetFont("","B",11);
		$this->Cell(0,5,$this->total,"TRB",2,"C");
		$this->SetFont("","",10);

		$this->Ln(5);
	}

	function pdf_AddFooter() {
		$this->SetFont("","B",10);
		$this->Cell(60,5,"�������","TRL");
		$this->Cell(60,5,"��������","TRL");
		$this->Cell(0,5,"�������","TRL",1);
		$this->SetFont("","",10);

		$this->Cell(60,5,$this->idata['received_by'][0],"LR");
		$this->Cell(60,5,$this->idata['created_by'][0],"LR");
		$this->Cell(0,5,$this->idata['payment_for'],"LR",1);

		$this->SetFont("","B",10);
		$this->Cell(60,5,"��������� �� ����������","LR");
		$this->Cell(60,5,"��������� �� ����������","LR");
		$this->Cell(0,5,"","LR",1);
		$this->SetFont("","",10);

		$this->Cell(60,5,$this->idata['received_by'][1],"BRL");
		$this->Cell(60,5,$this->idata['created_by'][1],"BRL");
		$this->Cell(0,5,"","BRL",1);

		$this->Ln(5);
	}

/* HTML FUNCTIONS */
	function html_AddHeader($original=1) {
		if ($this->html_show_start) {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=windows-1251">
	<style>
	<!--
		body, td { font-face: Arial, Helvetica, sans-serif; }
		b { font-size: 120%; }
		.boxed { border-top:1px solid black; border-right: 2px solid black; border-bottom: 1px solid black; }
		.trboxed { border-left: 1px solid black; border-bottom: 1px solid black; }
		.totals1 { border-left: 1px solid black; border-right: 1px solid black; }
		.totals2 { border-top: 2px solid black; }
		.invoice { width: 780px; }
	-->
	</style>
	<title><?="������� ".$this->idata['num']." �� ".$this->idata['date']?></title>
</head>
<body>
<?
		}
		$orig = "";
		if ($original)
			$orig = " (��������)";

		$title = "";
		if (!isset($this->idata["dds"]))
			$this->idata["dds"] = true;
		switch ($this->idata['type']) {
			case 0:
				$title = "������� �������";
				break;
			case 1:
				$title = "��������� �������";
				$this->idata["dds"] = false;
				break;
			case 2:
				$title = "�������� �������";
				break;
		}
?>
<center>
<div class="invoice">
<table cellpadding="2" cellspacing="0" border="0" width="100%" class="boxed">
<tr class="trboxed">
	<td class="trboxed" width="50%">��� �� ���������</td>
	<td class="trboxed" width="35%" align="right">�������� N:</td>
	<td class="trboxed" width="15%" align="center">�� ����</td>
</tr>
<tr>
	<td class="trboxed" valign="top" valign="middle"><big><big><b><?=$title?></b><?=$orig?></big></big></td>
	<td class="trboxed" align="right" valign="middle"><b><?=$this->idata['num']?></b></td>
	<td class="trboxed" align="center" valign="middle"><b><?=$this->idata['date']?></b></td>
</tr>
</table>
<br>
<?
	}

	function html_AddBuyerAndSeller() {

?>
<table cellpadding="2" cellspacing="0" border="0" width="100%" class="boxed">
<tr>
	<td class="trboxed" width="50%">�������</td>
	<td class="trboxed" width="50%">��������</td>
</tr>
<tr>
	<td class="trboxed" align="center"><big><b><?=$this->idata['buyer']?></b></big></td>
	<td class="trboxed" align="center"><big><b><?=$this->idata['seller']?></b></big></td>
</tr>
<tr>
	<td class="trboxed">
		<table width="100%" cellpadding="0" cellspacing="2" border="0">
<?		foreach ($this->client_fields as $i => $field) {
			$bdata = "";
			if (isset($this->idata['buyer_data'][$i]))
				$bdata = $this->idata['buyer_data'][$i];
?>
		<tr><td width="40%"><?=$field?></td><td width="60%"><?=$bdata?></td></tr>
<?		} ?>
		</table>
	</td>
	<td class="trboxed">
		<table width="100%" cellpadding="0" cellspacing="2" border="0">
<?		foreach ($this->client_fields as $i => $field) {
			$sdata = "";
			if (isset($this->idata['seller_data'][$i]))
				$sdata = $this->idata['seller_data'][$i];

?>
		<tr><td width="40%"><?=$field?></td><td width="60%"><?=$sdata?></td></tr>
<?		} ?>
		</table>
	</td>
</tr>
</table>
<br>
<?
	}

	function html_AddProducts() {
		$this->sum = 0;
?>
<table cellpadding="2" cellspacing="0" border="0" width="100%" class="boxed">
<tr>
	<td align="center" class="trboxed" width="5%"><b>N:</b></td>
	<td align="center" class="trboxed" width="45%"><b>������������</b></td>
	<td align="center" class="trboxed" width="10%"><b>�����.</b></td>
	<td align="center" class="trboxed" width="15%"><b>��. ����</b></td>
	<td align="center" class="trboxed" width="15%"><b>���� ����</b></td>
</tr>
<?		foreach ($this->idata['products'] as $i => $product) { ?>
<tr>
	<td align="center" class="trboxed"><?=$i+1?></td>
	<td align="left" class="trboxed"><?=$product[0]?></td>
	<td align="center" class="trboxed"><?=$product[1]?></td>
	<td align="center" class="trboxed"><?=$product[2]?></td>
	<td align="center" class="trboxed"><?=$product[1]*$product[2]?></td>
</tr>
<?		
			$this->sum += $product[1]*$product[2];
		}
?>
</table>
<br>
<?
		$this->vat = $this->sum * ($this->dds_percent / 100);
		if ($this->idata["dds"])
			$this->total = $this->sum + $this->vat;
		else
			$this->total = $this->sum;

		$this->total_text = number2lv($this->total);
	}

	function html_AddTotals() {
?>
<table cellpadding="2" cellspacing="0" border="0" width="100%" class="boxed">
<tr>
	<td class="totals1" width="50%"><b>������</b></td>
	<td width="25%"><b>��-� �� ��������</b></td>
	<td width="15%" align="center"><b><?=$this->sum?></b></td>
</tr>
<tr>
	<td class="totals1" rowspan="2" valign="top"><?=$this->total_text?><br></td>
<?	if ($this->idata["dds"]) { ?>
	<td><b>��� <?=$this->dds_percent?>%</b></td>
	<td align="center"><b><?=$this->vat?></b></td>
<?	} else { ?>
	<td colspan="2"><br></td>
<?	} ?>
</tr>
<tr>
	<td><b>���� ��������</b></td>
	<td class="totals2" align="center"><big><b><?=$this->total?></b></big></td>
</tr>
</table>
<br>
<?
	}

	function html_AddFooter() {
?>
<table cellpadding="2" cellspacing="0" border="0" width="100%" class="boxed">
<tr>
	<td class="trboxed" width="33%" valign="top">
<b>�������</b><br>
<?=$this->idata['received_by'][0]?><br>
<b>��������� �� ����������</b><br>
<?=$this->idata['received_by'][1]?><br>
	</td>
	<td class="trboxed" width="34%" valign="top">
<b>��������</b><br>
<?=$this->idata['created_by'][0]?><br>
<b>��������� �� ����������</b><br>
<?=$this->idata['created_by'][1]?><br>
	</td>
	<td class="trboxed" width="33%" valign="top">
<b>�������</b><br>
<?=$this->idata['payment_for']?>
	</td>
</tr>
</table>
<br>
</div>
</center>
<?
		if ($this->html_show_end) {
?>
</body>
</html>
<?
		}
	}
}

?>