#include <thread>
#include <nall/crc32.hpp>
#include <nall/detect.hpp>
#include <nall/file.hpp>
#include <nall/filemap.hpp>
#include <nall/function.hpp>
#include <nall/stdint.hpp>
#include <nall/blip/delta.hpp>
#include <nall/blip/linear.hpp>
#include <nall/blip/patch.hpp>
#include <phoenix/phoenix.hpp>
using namespace nall;
using namespace phoenix;

static const char *ApplicationName = "blip v01 - beta 3";

struct Blip {
  static volatile bool waiting;
  static string sourceName;
  static string targetName;
  static string changeName;
  static bool result;
  static string error;
  static function<void ()> callback;

  static void apply(const string &sourceName, const string &targetName, const string &changeName) {
    Blip::sourceName = sourceName;
    Blip::targetName = targetName;
    Blip::changeName = changeName;

    #if !defined(PLATFORM_WIN)
    waiting = true;
    //note: creating as an object causes exception during destruction, unsure why
    //blip will never create more than one extra thread, so this won't continue to leak memory
    std::thread *thread = new std::thread(Blip::apply_);
    while(waiting == true) { if(callback) callback(); usleep(20 * 1000); }
    #else
    apply_();
    #endif
  }

  static void create_linear(const string &sourceName, const string &targetName, const string &changeName) {
    Blip::sourceName = sourceName;
    Blip::targetName = targetName;
    Blip::changeName = changeName;

    #if !defined(PLATFORM_WIN)
    waiting = true;
    std::thread *thread = new std::thread(Blip::create_linear_);
    while(waiting == true) { if(callback) callback(); usleep(20 * 1000); }
    #else
    create_linear_();
    #endif
  }

  static void create_delta(const string &sourceName, const string &targetName, const string &changeName) {
    Blip::sourceName = sourceName;
    Blip::targetName = targetName;
    Blip::changeName = changeName;

    #if !defined(PLATFORM_WIN)
    waiting = true;
    std::thread *thread = new std::thread(Blip::create_delta_);
    while(waiting == true) { if(callback) callback(); usleep(20 * 1000); }
    #else
    create_delta_();
    #endif
  }

private:
  static void apply_() {
    error = "";
    BlipPatch blip;
    blip.openChange(changeName);
    blip.openSource(sourceName);
    blip.openTarget(targetName);
    result = blip.apply();
    error = blip.error;
    blip.close();
    waiting = false;
  }

  static void create_linear_() {
    BlipLinear blip;
    blip.openChange(changeName);
    blip.openSource(sourceName);
    blip.openTarget(targetName);
    blip.create();
    blip.close();
    waiting = false;
  }

  static void create_delta_() {
    BlipDelta blip;
    blip.openChange(changeName);
    blip.openSource(sourceName);
    blip.openTarget(targetName);
    blip.create();
    blip.close();
    waiting = false;
  }
};

volatile bool Blip::waiting;
string Blip::sourceName;
string Blip::targetName;
string Blip::changeName;
bool Blip::result;
string Blip::error;
function<void ()> Blip::callback;

struct Application : Window {
  Font defaultFont;
  Font boldFont;
  Font headerFont;

  struct Navigation : VerticalLayout {
    unsigned pageNumber;
    Widget spacer;
    HorizontalLayout layout;
    Widget horizontalSpacer;
    Button back;
    Button next;
    Button quit;
  } navigation;

  struct Mode : VerticalLayout {
    Label header;
    Label information;
    RadioBox applyPatch;
    Label applyPatchInformation;
    RadioBox createLinearPatch;
    Label createLinearPatchInformation;
    RadioBox createDeltaPatch;
    Label createDeltaPatchInformation;
  } mode;

  struct ApplyPatch : VerticalLayout {
    Label header;
    Label information;
    HorizontalLayout patchLayout;
    Label patchLabel;
    LineEdit patchPath;
    Button patchBrowse;
    HorizontalLayout sourceLayout;
    Label sourceLabel;
    LineEdit sourcePath;
    Button sourceBrowse;
    Label targetInformation;
    HorizontalLayout targetLayout;
    Label targetLabel;
    LineEdit targetPath;
    Button targetBrowse;
  } applyPatch;

  struct CreateLinearPatch : VerticalLayout {
    Label header;
    Label information;
    HorizontalLayout sourceLayout;
    Label sourceLabel;
    LineEdit sourcePath;
    Button sourceBrowse;
    HorizontalLayout targetLayout;
    Label targetLabel;
    LineEdit targetPath;
    Button targetBrowse;
    HorizontalLayout patchLayout;
    Label patchLabel;
    LineEdit patchPath;
    Button patchBrowse;
  } createLinearPatch;

  struct CreateDeltaPatch : VerticalLayout {
    Label header;
    Label information;
    HorizontalLayout sourceLayout;
    Label sourceLabel;
    LineEdit sourcePath;
    Button sourceBrowse;
    HorizontalLayout targetLayout;
    Label targetLabel;
    LineEdit targetPath;
    Button targetBrowse;
    HorizontalLayout patchLayout;
    Label patchLabel;
    LineEdit patchPath;
    Button patchBrowse;
  } createDeltaPatch;

  struct Result : VerticalLayout {
    Label header;
    Label information;
  } result;

  void create() {
    setTitle(ApplicationName);
    setGeometry({ 128, 128, 500, 300 });

    defaultFont.setSize(8);
    boldFont.setSize(8);
    boldFont.setBold();
    headerFont.setSize(16);
    setWidgetFont(defaultFont);

    navigation.pageNumber = 1;
    navigation.back.setText("Back");
    navigation.back.setEnabled(false);
    navigation.next.setText("Next");
    navigation.quit.setText("Quit");

    navigation.setMargin(5);
    navigation.append(navigation.spacer, ~0, ~0);
    navigation.layout.append(navigation.horizontalSpacer, ~0, 0);
    navigation.layout.append(navigation.back, 80, 0, 5);
    navigation.layout.append(navigation.next, 80, 0, 5);
    navigation.layout.append(navigation.quit, 80, 0, 0);
    navigation.append(navigation.layout);
    append(navigation);

    mode.header.setText("blip :: Binary Differencing Tool");
    mode.header.setFont(headerFont);
    mode.information.setText("What would you like to do?");
    mode.applyPatch.setText("Apply Patch");
    mode.applyPatch.setFont(boldFont);
    mode.applyPatchInformation.setText(
      "Applies a blip patch, transforming a source file into a modified target file."
    );
    mode.createLinearPatch.setText("Create Linear Patch");
    mode.createLinearPatch.setFont(boldFont);
    mode.createLinearPatchInformation.setText(
      "Use this option if data *was not* inserted or deleted on target file.\n"
      "In other words, use this if data was merely modified (eg patching a binary.)\n"
      "This option is faster, but will produce larger patches."
    );
    mode.createDeltaPatch.setText("Create Delta Patch");
    mode.createDeltaPatch.setFont(boldFont);
    mode.createDeltaPatchInformation.setText(
      "Use this option if data *was* inserted or deleted on target file.\n"
      "In other words, use this if data was expanded or removed (eg editing a text file.)\n"
      "This option will produce smaller patches, but is *much* slower."
    );
    RadioBox::group(mode.applyPatch, mode.createLinearPatch, mode.createDeltaPatch);

    mode.setMargin(5);
    mode.append(mode.header, ~0, 0, 5);
    mode.append(mode.information, ~0, 0, 5);
    mode.append(mode.applyPatch, ~0, 0);
    mode.append(mode.applyPatchInformation, ~0, 0, 5);
    mode.append(mode.createLinearPatch, ~0, 0);
    mode.append(mode.createLinearPatchInformation, ~0, 0, 5);
    mode.append(mode.createDeltaPatch, ~0, 0);
    mode.append(mode.createDeltaPatchInformation, ~0, 0, 5);
    append(mode);

    applyPatch.header.setText("blip :: Apply Patch");
    applyPatch.header.setFont(headerFont);
    applyPatch.information.setText(
      "Choose a blip patch, and a source file to apply patch to."
    );
    applyPatch.patchLabel.setText("Patch:");
    applyPatch.patchPath.setEditable(false);
    applyPatch.patchBrowse.setText("Browse ...");
    applyPatch.sourceLabel.setText("Source:");
    applyPatch.sourcePath.setEditable(false);
    applyPatch.sourceBrowse.setText("Browse ...");
    applyPatch.targetInformation.setText(
      "Optional: you may specify a custom target file.\n"
      "If this is left blank, patch will be applied to source file after making a backup copy."
    );
    applyPatch.targetLabel.setText("Target:");
    applyPatch.targetPath.setEditable(false);
    applyPatch.targetBrowse.setText("Browse ...");

    applyPatch.setMargin(5);
    applyPatch.append(applyPatch.header, ~0, 0, 5);
    applyPatch.append(applyPatch.information, ~0, 0, 5);
    applyPatch.patchLayout.append(applyPatch.patchLabel, 50, 0, 5);
    applyPatch.patchLayout.append(applyPatch.patchPath, ~0, 0, 5);
    applyPatch.patchLayout.append(applyPatch.patchBrowse, 0, 0);
    applyPatch.append(applyPatch.patchLayout, 5);
    applyPatch.sourceLayout.append(applyPatch.sourceLabel, 50, 0, 5);
    applyPatch.sourceLayout.append(applyPatch.sourcePath, ~0, 0, 5);
    applyPatch.sourceLayout.append(applyPatch.sourceBrowse, 0, 0);
    applyPatch.append(applyPatch.sourceLayout, 5);
    applyPatch.append(applyPatch.targetInformation, ~0, 0, 5);
    applyPatch.targetLayout.append(applyPatch.targetLabel, 50, 0, 5);
    applyPatch.targetLayout.append(applyPatch.targetPath, ~0, 0, 5);
    applyPatch.targetLayout.append(applyPatch.targetBrowse, 0, 0);
    applyPatch.append(applyPatch.targetLayout, 5);
    append(applyPatch);
    applyPatch.setVisible(false);

    createLinearPatch.header.setText("blip :: Create Linear Patch");
    createLinearPatch.header.setFont(headerFont);
    createLinearPatch.information.setText(
      "Choose the source (original) file, and target (modified) file.\n"
      "Afterwards, select a filename for the new blip patch."
    );
    createLinearPatch.sourceLabel.setText("Source:");
    createLinearPatch.sourcePath.setEditable(false);
    createLinearPatch.sourceBrowse.setText("Browse ...");
    createLinearPatch.targetLabel.setText("Target:");
    createLinearPatch.targetPath.setEditable(false);
    createLinearPatch.targetBrowse.setText("Browse ...");
    createLinearPatch.patchLabel.setText("Patch:");
    createLinearPatch.patchPath.setEditable(false);
    createLinearPatch.patchBrowse.setText("Browse ...");

    createLinearPatch.setMargin(5);
    createLinearPatch.append(createLinearPatch.header, ~0, 0, 5);
    createLinearPatch.append(createLinearPatch.information, ~0, 0, 5);
    createLinearPatch.sourceLayout.append(createLinearPatch.sourceLabel, 50, 0, 5);
    createLinearPatch.sourceLayout.append(createLinearPatch.sourcePath, ~0, 0, 5);
    createLinearPatch.sourceLayout.append(createLinearPatch.sourceBrowse, 0, 0);
    createLinearPatch.append(createLinearPatch.sourceLayout, 5);
    createLinearPatch.targetLayout.append(createLinearPatch.targetLabel, 50, 0, 5);
    createLinearPatch.targetLayout.append(createLinearPatch.targetPath, ~0, 0, 5);
    createLinearPatch.targetLayout.append(createLinearPatch.targetBrowse, 0, 0);
    createLinearPatch.append(createLinearPatch.targetLayout, 5);
    createLinearPatch.patchLayout.append(createLinearPatch.patchLabel, 50, 0, 5);
    createLinearPatch.patchLayout.append(createLinearPatch.patchPath, ~0, 0, 5);
    createLinearPatch.patchLayout.append(createLinearPatch.patchBrowse, 0, 0);
    createLinearPatch.append(createLinearPatch.patchLayout, 5);
    append(createLinearPatch);
    createLinearPatch.setVisible(false);

    createDeltaPatch.header.setText("blip :: Create Delta Patch");
    createDeltaPatch.header.setFont(headerFont);
    createDeltaPatch.information.setText(
      "Choose the source (original) file, and target (modified) file.\n"
      "Afterwards, select a filename for the new blip patch."
    );
    createDeltaPatch.sourceLabel.setText("Source:");
    createDeltaPatch.sourcePath.setEditable(false);
    createDeltaPatch.sourceBrowse.setText("Browse ...");
    createDeltaPatch.targetLabel.setText("Target:");
    createDeltaPatch.targetPath.setEditable(false);
    createDeltaPatch.targetBrowse.setText("Browse ...");
    createDeltaPatch.patchLabel.setText("Patch:");
    createDeltaPatch.patchPath.setEditable(false);
    createDeltaPatch.patchBrowse.setText("Browse ...");

    createDeltaPatch.setMargin(5);
    createDeltaPatch.append(createDeltaPatch.header, ~0, 0, 5);
    createDeltaPatch.append(createDeltaPatch.information, ~0, 0, 5);
    createDeltaPatch.sourceLayout.append(createDeltaPatch.sourceLabel, 50, 0, 5);
    createDeltaPatch.sourceLayout.append(createDeltaPatch.sourcePath, ~0, 0, 5);
    createDeltaPatch.sourceLayout.append(createDeltaPatch.sourceBrowse, 0, 0);
    createDeltaPatch.append(createDeltaPatch.sourceLayout, 5);
    createDeltaPatch.targetLayout.append(createDeltaPatch.targetLabel, 50, 0, 5);
    createDeltaPatch.targetLayout.append(createDeltaPatch.targetPath, ~0, 0, 5);
    createDeltaPatch.targetLayout.append(createDeltaPatch.targetBrowse, 0, 0);
    createDeltaPatch.append(createDeltaPatch.targetLayout, 5);
    createDeltaPatch.patchLayout.append(createDeltaPatch.patchLabel, 50, 0, 5);
    createDeltaPatch.patchLayout.append(createDeltaPatch.patchPath, ~0, 0, 5);
    createDeltaPatch.patchLayout.append(createDeltaPatch.patchBrowse, 0, 0);
    createDeltaPatch.append(createDeltaPatch.patchLayout, 5);
    append(createDeltaPatch);
    createDeltaPatch.setVisible(false);

    result.header.setText("blip :: Result");
    result.header.setFont(headerFont);
    result.information.setText("...");

    result.setMargin(5);
    result.append(result.header, ~0, 0, 5);
    result.append(result.information, ~0, 0, 5);
    append(result);
    result.setVisible(false);

    navigation.back.onTick = [this]() {
      navigation.pageNumber = 1;
      applyPatch.setVisible(false);
      createLinearPatch.setVisible(false);
      createDeltaPatch.setVisible(false);
      mode.setVisible(true);
      navigation.back.setEnabled(false);
      navigation.next.setEnabled(true);
    };

    navigation.next.onTick = [this]() {
      navigation.pageNumber++;
      mode.setVisible(false);

      if(navigation.pageNumber == 2) {
        navigation.back.setEnabled(true);
        navigation.next.setEnabled(false);
        if(mode.applyPatch.checked()) {
          applyPatch.setVisible(true);
          applyPatch.patchBrowse.setFocused();
        }
        if(mode.createLinearPatch.checked()) {
          createLinearPatch.setVisible(true);
          createLinearPatch.sourceBrowse.setFocused();
        }
        if(mode.createDeltaPatch.checked()) {
          createDeltaPatch.setVisible(true);
          createDeltaPatch.sourceBrowse.setFocused();
        }
      }

      if(navigation.pageNumber == 3) {
        string message;
        if(mode.applyPatch.checked()) message = "Ready to apply patch.\n";
        if(mode.createLinearPatch.checked()) message = "Ready to create linear patch.\n";
        if(mode.createDeltaPatch.checked()) message = "Ready to create delta patch.\n";
        message.append("Note: UI will be unresponsive during this time, so please be patient!");
        MessageWindow::information(*this, message);
        this->setTitle({ ApplicationName, " - Working ..." });
        OS::processEvents();

        navigation.back.setEnabled(false);
        navigation.next.setEnabled(false);
        navigation.quit.setEnabled(false);

        if(mode.applyPatch.checked()) {
          string sourceName = applyPatch.sourcePath.text();
          string targetName = applyPatch.targetPath.text();
          string patchName = applyPatch.patchPath.text();
          if(targetName == "") targetName = { sourceName, ".bak" };

          Blip::callback = [this]() {
            OS::processEvents();
            usleep(20 * 1000);
          };
          Blip::apply(sourceName, targetName, patchName);

          if(Blip::result == true) {
            if(applyPatch.targetPath.text() == "") {
              rename(sourceName, string(sourceName, ".tmp"));
              rename(string(sourceName, ".bak"), sourceName);
              rename(string(sourceName, ".tmp"), string(sourceName, ".bak"));
            }
            result.information.setText("Patch application was successful!");
          } else {
            unlink(string(sourceName, ".bak"));
            result.information.setText({
              "Patch application failed!\n",
              "Reason: ", Blip::error, "\n",
              "Please ensure that the patch and target file are correct."
            });
          }
          navigation.next.onTick();
        }

        if(mode.createLinearPatch.checked()) {
          string sourceName = createLinearPatch.sourcePath.text();
          string targetName = createLinearPatch.targetPath.text();
          string patchName = createLinearPatch.patchPath.text();

          Blip::callback = [this]() {
            OS::processEvents();
            usleep(20 * 1000);
          };
          Blip::create_linear(sourceName, targetName, patchName);

          result.information.setText("Linear patch creation was successful!");
          navigation.next.onTick();
        }

        if(mode.createDeltaPatch.checked()) {
          string sourceName = createDeltaPatch.sourcePath.text();
          string targetName = createDeltaPatch.targetPath.text();
          string patchName = createDeltaPatch.patchPath.text();

          Blip::callback = [this]() {
            OS::processEvents();
            usleep(20 * 1000);
          };
          Blip::create_delta(sourceName, targetName, patchName);

          result.information.setText("Delta patch creation was successful!");
          navigation.next.onTick();
        }
      }

      if(navigation.pageNumber == 4) {
        applyPatch.setVisible(false);
        createLinearPatch.setVisible(false);
        createDeltaPatch.setVisible(false);
        result.setVisible(true);
        navigation.quit.setEnabled(true);
      }
    };

    navigation.quit.onTick = &OS::quit;

    applyPatch.patchBrowse.onTick = [this]() {
      string filename = OS::fileLoad(*this, "", "blip patches (*.blip)");
      applyPatch.patchPath.setText(filename);
      navigation.next.setEnabled(
        applyPatch.patchPath.text() != "" &&
        applyPatch.sourcePath.text() != "" &&
        applyPatch.patchPath.text() != applyPatch.sourcePath.text() &&
        applyPatch.patchPath.text() != applyPatch.targetPath.text() &&
        applyPatch.sourcePath.text() != applyPatch.targetPath.text()
      );
    };

    applyPatch.sourceBrowse.onTick = [this]() {
      string filename = OS::fileLoad(*this, "", "All files (*)");
      applyPatch.sourcePath.setText(filename);
      navigation.next.setEnabled(
        applyPatch.patchPath.text() != "" &&
        applyPatch.sourcePath.text() != "" &&
        applyPatch.patchPath.text() != applyPatch.sourcePath.text() &&
        applyPatch.patchPath.text() != applyPatch.targetPath.text() &&
        applyPatch.sourcePath.text() != applyPatch.targetPath.text()
      );
    };

    applyPatch.targetBrowse.onTick = [this]() {
      string filename = OS::fileSave(*this, "", "All files (*)");
      applyPatch.targetPath.setText(filename);
      navigation.next.setEnabled(
        applyPatch.patchPath.text() != "" &&
        applyPatch.sourcePath.text() != "" &&
        applyPatch.patchPath.text() != applyPatch.sourcePath.text() &&
        applyPatch.patchPath.text() != applyPatch.targetPath.text() &&
        applyPatch.sourcePath.text() != applyPatch.targetPath.text()
      );
    };

    createLinearPatch.sourceBrowse.onTick = [this]() {
      string filename = OS::fileLoad(*this, "", "All files (*)");
      createLinearPatch.sourcePath.setText(filename);
      navigation.next.setEnabled(
        createLinearPatch.sourcePath.text() != "" &&
        createLinearPatch.targetPath.text() != "" &&
        createLinearPatch.patchPath.text() != "" &&
        createLinearPatch.sourcePath.text() != createLinearPatch.targetPath.text() &&
        createLinearPatch.sourcePath.text() != createLinearPatch.patchPath.text() &&
        createLinearPatch.targetPath.text() != createLinearPatch.patchPath.text()
      );
    };

    createLinearPatch.targetBrowse.onTick = [this]() {
      string filename = OS::fileLoad(*this, "", "All files (*)");
      createLinearPatch.targetPath.setText(filename);
      navigation.next.setEnabled(
        createLinearPatch.sourcePath.text() != "" &&
        createLinearPatch.targetPath.text() != "" &&
        createLinearPatch.patchPath.text() != "" &&
        createLinearPatch.sourcePath.text() != createLinearPatch.targetPath.text() &&
        createLinearPatch.sourcePath.text() != createLinearPatch.patchPath.text() &&
        createLinearPatch.targetPath.text() != createLinearPatch.patchPath.text()
      );
    };

    createLinearPatch.patchBrowse.onTick = [this]() {
      string filename = OS::fileSave(*this, "", "blip patches (*.blip)");
      createLinearPatch.patchPath.setText(filename);
      navigation.next.setEnabled(
        createLinearPatch.sourcePath.text() != "" &&
        createLinearPatch.targetPath.text() != "" &&
        createLinearPatch.patchPath.text() != "" &&
        createLinearPatch.sourcePath.text() != createLinearPatch.targetPath.text() &&
        createLinearPatch.sourcePath.text() != createLinearPatch.patchPath.text() &&
        createLinearPatch.targetPath.text() != createLinearPatch.patchPath.text()
      );
    };

    createDeltaPatch.sourceBrowse.onTick = [this]() {
      string filename = OS::fileLoad(*this, "", "All files (*)");
      createDeltaPatch.sourcePath.setText(filename);
      navigation.next.setEnabled(
        createDeltaPatch.sourcePath.text() != "" &&
        createDeltaPatch.targetPath.text() != "" &&
        createDeltaPatch.patchPath.text() != "" &&
        createDeltaPatch.sourcePath.text() != createDeltaPatch.targetPath.text() &&
        createDeltaPatch.sourcePath.text() != createDeltaPatch.patchPath.text() &&
        createDeltaPatch.targetPath.text() != createDeltaPatch.patchPath.text()
      );
    };

    createDeltaPatch.targetBrowse.onTick = [this]() {
      string filename = OS::fileLoad(*this, "", "All files (*)");
      createDeltaPatch.targetPath.setText(filename);
      navigation.next.setEnabled(
        createDeltaPatch.sourcePath.text() != "" &&
        createDeltaPatch.targetPath.text() != "" &&
        createDeltaPatch.patchPath.text() != "" &&
        createDeltaPatch.sourcePath.text() != createDeltaPatch.targetPath.text() &&
        createDeltaPatch.sourcePath.text() != createDeltaPatch.patchPath.text() &&
        createDeltaPatch.targetPath.text() != createDeltaPatch.patchPath.text()
      );
    };

    createDeltaPatch.patchBrowse.onTick = [this]() {
      string filename = OS::fileSave(*this, "", "blip patches (*.blip)");
      createDeltaPatch.patchPath.setText(filename);
      navigation.next.setEnabled(
        createDeltaPatch.sourcePath.text() != "" &&
        createDeltaPatch.targetPath.text() != "" &&
        createDeltaPatch.patchPath.text() != "" &&
        createDeltaPatch.sourcePath.text() != createDeltaPatch.targetPath.text() &&
        createDeltaPatch.sourcePath.text() != createDeltaPatch.patchPath.text() &&
        createDeltaPatch.targetPath.text() != createDeltaPatch.patchPath.text()
      );
    };

    setVisible();
    mode.applyPatch.setFocused();

    onClose = &OS::quit;
  }
} application;

int main(int argc, char **argv) {
  if(argc == 5 && !strcmp(argv[1], "create-linear")) {
    Blip::create_linear(argv[2], argv[3], argv[4]);
    return 0;
  }

  if(argc == 5 && !strcmp(argv[1], "create-delta")) {
    Blip::create_delta(argv[2], argv[3], argv[4]);
    return 0;
  }

  if(argc == 5 && !strcmp(argv[1], "apply")) {
    Blip::apply(argv[2], argv[3], argv[4]);
    if(Blip::result == false) {
      print(
        "blip: patch application failed\n"
        "Reason: ", Blip::error, "\n"
      );
    }
    return 0;
  }

  application.create();
  OS::main();
  return 0;
}
