g++-4.5 -std=gnu++0x -pthread -I. -O3 -fomit-frame-pointer -c phoenix/phoenix.cpp `pkg-config --cflags gtk+-2.0` -DPHOENIX_GTK
g++-4.5 -std=gnu++0x -pthread -I. -O3 -fomit-frame-pointer -c blip.cpp
g++-4.5 -pthread -s -o blip-gtk blip.o phoenix.o `pkg-config --libs gtk+-2.0` -lX11
rm *.o
