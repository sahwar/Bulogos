void pSeparator::constructor() {
  widget = gtk_separator_menu_item_new();
}
