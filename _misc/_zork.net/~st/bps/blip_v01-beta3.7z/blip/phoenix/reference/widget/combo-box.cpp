void pComboBox::append(const string &text) {
}

void pComboBox::reset() {
}

unsigned pComboBox::selection() {
  return 0;
}

void pComboBox::setSelection(unsigned row) {
}

void pComboBox::constructor() {
}
