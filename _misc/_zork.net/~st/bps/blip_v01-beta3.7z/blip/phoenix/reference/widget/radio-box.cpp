bool pRadioBox::checked() {
  return false;
}

void pRadioBox::setChecked() {
}

void pRadioBox::setGroup(const reference_array<RadioBox&> &group) {
}

void pRadioBox::setText(const string &text) {
}

void pRadioBox::constructor() {
}
