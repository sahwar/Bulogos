void pAction::setEnabled(bool enabled) {
}

void pAction::setVisible(bool visible) {
}

void pAction::constructor() {
}
