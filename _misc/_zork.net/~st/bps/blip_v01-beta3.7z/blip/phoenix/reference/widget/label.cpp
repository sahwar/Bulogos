void pLabel::setText(const string &text) {
}

void pLabel::constructor() {
}
