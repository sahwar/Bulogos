void pButton::setText(const string &text) {
}

void pButton::constructor() {
}
