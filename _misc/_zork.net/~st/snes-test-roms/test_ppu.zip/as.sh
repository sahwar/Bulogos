xkas test_hello.sfc test_hello.asm
xkas test_noise.sfc test_noise.asm
