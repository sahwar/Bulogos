#### General information

* **Version:** 2.6.0
* **Device:** Xiaomi Mi A1
* **Android Version:**  Android 9 (stock)
* **Server name:** conversations.im, jabber.at or self hosted
* **Server software:** ejabberd 19.09.1 or prosody 0.11.3 (if known)
* **Installed server modules:** Stream Managment, CSI, MAM
* **Conversations source:** PlayStore, PlayStore Beta Channel, F-Droid, self build (latest HEAD)


#### Steps to reproduce

1. …
2. …


#### Expected result

What is the expected output? 


#### Actual result

What do you see instead?


#### Debug output

Please post the output of adb logcat. The log should begin with the start of Conversations and include all the
steps it takes to reproduce the problem.

````
adb logcat -s conversations
````
