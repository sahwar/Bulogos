package eu.siacs.conversations.ui.interfaces;

import java.util.List;

import eu.siacs.conversations.ui.util.Attachment;

public interface OnMediaLoaded {

    void onMediaLoaded(List<Attachment> attachments);
}
