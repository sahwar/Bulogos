package eu.siacs.conversations.utils;

import eu.siacs.conversations.ui.MagicCreateActivity;
import eu.siacs.conversations.ui.WelcomeActivity;

public class InstallReferrerUtils {

    public InstallReferrerUtils(WelcomeActivity welcomeActivity) {

    }

    public static void markInstallReferrerExecuted(MagicCreateActivity magicCreateActivity) {
        //stub
    }
}