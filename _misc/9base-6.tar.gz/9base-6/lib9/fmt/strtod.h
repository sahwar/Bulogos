extern double __NaN(void);
extern double __Inf(int);
extern double __isNaN(double);
extern double __isInf(double, int);
