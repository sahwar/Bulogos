extern double __NaN(void);
extern double __Inf(int);
extern int __isNaN(double);
extern int __isInf(double, int);
