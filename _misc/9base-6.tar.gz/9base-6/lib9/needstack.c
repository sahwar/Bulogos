#include <u.h>
#include <libc.h>

void
needstack(int howmuch)
{
	USED(howmuch);
}
