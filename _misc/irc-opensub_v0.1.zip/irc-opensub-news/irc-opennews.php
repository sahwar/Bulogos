<?php
/**
 *
 * @author char0n
 * @version 0.1
 * @copyright Jul 14, 2006
 * @extensions_required - CURL, ICONV
 * -- Written in PHP4
 */

// Supress notices
@error_reporting(E_ALL ^ E_NOTICE);
define('LF', "\n");

class IRCOpenNews
{
	var $mDelay;
	var $mHost;
	var $mUrl;
	var $mPort;
	var $mMethod;
	var $mUserAgent;
	var $mContent;
	var $mSubtitles;
	var $mURLS;
	var $mPREP;
	var $mHeader;
	
	function IRCOpenNews()
	{
		$this->mDelay     = 5; // delay in minutes
		$this->mHost      = 'http://www.opensubtitles.org';
	        $this->mUrl       = '/en/search/subaddunixdate-'.(time() - ($this->mDelay*60)).'/simplexml';
		$this->mPort      = 80;
		$this->mMethod    = 'GET';
		$this->mUserAgent = 'IrcNewsBot v0.1';
		$this->mContent   = '';
		$this->mSubtitles = array();
		$this->mSubtitles = array();
		$this->mPREP           = '14=(3SUB14)= ';
		$this->mHeader    = 'IRC OpenNewser';
	}
	
	function Process()
	{
		$this->_get_opensub_simplexml();
		$this->_parse();
	}
	
	function Output()
	{
		$c = 0;
		foreach ($this->mSubtitles as $moviename)
		{
		     echo $this->mPREP.$this->mHeader.LF;
		     echo $this->_format_news($moviename, $this->mURLS[$c]);
		     ++$c;
		}
	}
	
	function _format_news($moviename, $url)
	{
		return sprintf('%s%s - %s%s'.LF, $this->mPREP, $moviename, $this->mHost, $url);
	}
	
	function _get_opensub_simplexml()
	{
		$XmlHTTP = &new XmlHTTP;
		$XmlHTTP->setHost($this->mHost.$this->mUrl);
		$XmlHTTP->setPort($this->mPort);
		$XmlHTTP->setMethod($this->mMethod);
		$XmlHTTP->setUserAgent($this->mUserAgent);
		$this->mContent = $this->_reencode_content($XmlHTTP->getXmlData());
		$XmlHTTP = NULL;
		unset($XmlHTTP);
	}
	
	function _parse()
	{
		$this->_parse_subtitles();
		$this->_parse_URLS();
	}
	
	function _parse_subtitles()
	{
		preg_match_all('/<movie><\!\[CDATA\[(.+?)\]\]><\/movie>/', $this->mContent, $matches);
		$this->mSubtitles = $matches[1];
	}
	
	function _parse_urls()
	{
		preg_match_all('/<detail>(.+?)<\/detail>/', $this->mContent, $matches);
		$this->mURLS = $matches[1];		
	}
	
	function _reencode_content($content)
	{
		return iconv('UTF-8' , 'CP1250//TRANSLIT', $content);		
	}
	
}
 
 
/*
 * XMLHTTP class
 * @author: char0n 
 */

// XmlHTTP class
class XmlHTTP
{
    var $mHost;
    var $mPort = 80;
    var $mReturnResponse = TRUE;
    var $mTimeout = 30;
    var $mUserAgent = 'Mozilla';
    var $mReturnHeaders = FALSE;
    var $mProxy = NULL;
    var $mSocket;
    var $mMethod = 'GET';
    var $mPostVars;
    var $mXmlData;

    // Public method
    function setHost($host)
    {
		$this->mHost = $host;
    }

    // Public method
    function setPort($port)
    {
		$this->mPort = $port;
    }

    // Public method
    function setReturnResponse($response)
    {
		$this->mReturnResponse = $response;
    }

    // Public method
    function setTimeout($timeout)
    {
		$this->mTimeout = $timeout;
    }

    // Public method
    function setUserAgent($user_agent)
    {
		$this->mUserAgent = $user_agent;
    }

    // Public method
    function setReturnHeaders($headers)
    {
		$this->mReturnHeaders = $headers;
    }

    // Public method
    function setProxy($proxy)
    {
		$this->mProxy = $proxy;
    }

    // Public method
    function setMethod($method)
    {
		$this->mMethod = $method;
    }

    // Public method
    function setPostVars($postvars)
    {
		$this->mPostVars = $postvars;
    }

    // Public method
    function getXmlData()
    {
		$this->_open_connection();
		$this->_set_options();
		$this->_get_response();
		$this->_close_connection();
		return $this->mXmlData;
    }

    // Private method
    function _open_connection()
    {
		$this->mSocket = curl_init();
    }

    // Private method
    function _close_connection()
    {
		curl_close($this->mSocket);
    }

    // Private method
    function _set_options()
    {
		curl_setopt($this->mSocket, CURLOPT_URL, $this->mHost);
		curl_setopt($this->mSocket, CURLOPT_RETURNTRANSFER, $this->mReturnResponse);
		curl_setopt($this->mSocket, CURLOPT_TIMEOUT, $this->mTimeout);
		curl_setopt($this->mSocket, CURLOPT_PORT, $this->mPort);
		curl_setopt($this->mSocket, CURLOPT_USERAGENT, $this->mUserAgent);
		curl_setopt($this->mSocket, CURLOPT_HEADER, $this->mReturnHeaders); 
		if ($this->mProxy != NULL)
		    curl_setopt($this->mSocket, CURLOPT_PROXY, $this->mProxy); 
		if ($this->mMethod == 'GET')
		    curl_setopt($this->mSocket, URLOPT_HTTPGET, 1); 
		if ($this->mMethod == 'POST')
		{
		    curl_setopt($this->mSocket, CURLOPT_POST, 1); 
		    if ($this->mPortVars != '')
			curl_setopt($this->mSocket, CURLOPT_POSTFIELDS, $this->mPostVars);
		}

    }

    function _get_response()
    {
		$this->mXmlData = curl_exec($this->mSocket) or die('No route to '.$this->mHost);
    }
    
}

$IRCOpenNews = &new IRCOpenNews;
$IRCOpenNews->Process();
$IRCOpenNews->Output();
?>
