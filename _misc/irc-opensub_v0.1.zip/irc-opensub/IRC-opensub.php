<?php
/**
 *
 * @author char0n
 * @version 0.1
 * @copyright Jul 4, 2006 *
 * @extensions_required - CURL, ICONV
 * -- Written in PHP4
 */
 
// Supress notices
@error_reporting(E_ALL ^ E_NOTICE);


// Opensuber class
class IRCOpenSub
{
	var $mHost;         // Opensubtitle.org 
	var $mInput;        // User Input buffer
	var $mMovieName;     // Movie name that user requested
	var $mNumResults;    // Default results returned
	var $mMaxNumResults; // Maximum results returned
	var $mSumFiles;      // How many CDs
	var $mLang;          // Subtitle language
	var $mResults;       // Number of items found
	var $mProcessTime;   // Search time
	var $mSubtitles;     // Subtitle's names
	var $mURLS;          // Subtitle's urls
	var $mContent;       // HTTP content returned by opensubitles.org
	var $mPREP;          // Output prepender
	var $mShowMovieNames; // Printing movie names along with subtitle urls
	var $mDefLang;        // Default subtitle language used for searching
	var $mLangs;          // All supported languages
	
	// construct -- Inicializing variables
	function IRCOpenSub()
	{
		$this->mSubtitles      = array();
		$this->mURLS           = array();
		$this->mHost           = 'http://www.opensubtitles.org/en';
		$this->mNumResults     = 1;
		$this->mMaxNumResults  = 9;
		$this->mPREP           = '14=(3SUB14)= ';
		$this->mShowMovieNames = FALSE;
		$this->mDefLang        = 'slo,cze';
		$this->mLangs          = array('sq' => 'alb',
									   'hy' => 'arm',
									   'ay' => 'ass',
									   'bs' => 'bos',
									   'bg' => 'bul',
									   'hr' => 'hrv',
									   'cs' => 'cze',
									   'da' => 'dan',
									   'nl' => 'dut',
									   'en' => 'eng',
									   'et' => 'est',
									   'fi' => 'fin',
									   'fr' => 'fre',
									   'de' => 'ger',
									   'gr' => 'ell',
									   'he' => 'heb',
									   'hu' => 'hun',
									   'zh' => 'chi',
									   'it' => 'ita',
									   'ja' => 'jpn',
									   'kk' => 'kaz',
									   'lv' => 'lav',
									   'pl' => 'pol',
									   'pt' => 'por',
									   'pb' => 'pob',
									   'ro' => 'rum',
									   'ru' => 'rus',
									   'sr' => 'scc',
									   'sk' => 'slo',
									   'sl' => 'slv',
									   'es' => 'spa',
									   'sv' => 'swe',
									   'th' => 'tha',
									   'tr' => 'tur',
									   'uk' => 'ukr',
								       'all'=> 'all');
	}
	
	// public method -- main class processor
	function Process()
	{
		$this->_process_input();
		$this->_get_opensub_simplexml();
		$this->_parse();
		$this->_clear_Opensub_content();
	}
	
	// public method -- printing movie names along with subtitle urls
	function setShowMovieNames($show = TRUE)
	{
		$this->mShowMovieNames = $show;
	}
	
	// public method -- default language
	function setDefLang($lang)
	{
		$this->mDefLang = $lang;
	}
	
	// public method -- setting user search string
	function setInput($input)
	{
		$this->mInput = trim($input);
	}
	
	// public method -- printing search results 
	function Output()
	{
	    $this->mNumResults = ($this->mNumResults > $this->mMaxNumResults) ? $this->mMaxNumResults : $this->mNumResults;

		// No Match found
		if (@count($this->mSubtitles) == 0)
		{
			echo $this->_format_line('No match found');
			return;
		}
		$output = $this->_format_line('Results: '.$this->mResults.' ('.$this->mProcessTime.'s)');
		$c = 0;
		$this->mNumResults = (@count($this->mSubtitles) < $this->mNumResults) ? @count($this->mSubtitles) : $this->mNumResults;
		while ($this->mNumResults > 0)
		{
			$output .= (($this->mShowMovieNames == TRUE) ? $this->_format_line($this->mSubtitles[$c]) : '').
			           $this->_format_line(substr($this->mHost, 0, strlen($this->mHost) - 3).$this->mURLS[$c]);
			--$this->mNumResults;
			++$c;
		}
		echo $this->_reencode_content($output);
	}
	
	/**
	 * Private methods
	 * @abstract - methods names are self describtive
	 */
	 	 
	function _format_line($line)
	{
		return $this->mPREP.$line."\n";
	}
	
	function _process_input()
	{
		$pattern     = '/^\s*(?:(\d+)\s+)?(\w+(?:\s+\w+)*?)(?:\s+((?:sq|hy|ay|bs|bg|hr|cs|da|nl|en|et|fi|fr|de|gr|he|hu|zh|it|ja|kk|lv|pl|pt|pb|ro|ru|sr|sk|sl|es|sv|th|tr|uk|al)(?:\s*,\s*(?:sq|hy|ay|bs|bg|hr|cs|da|nl|en|et|fi|fr|de|gr|he|hu|zh|it|ja|kk|lv|pl|pt|pb|ro|ru|sr|sk|sl|es|sv|th|tr|uk|al))*))?(?:\s+(\d+)cd)?\s*$/';
		//$old_pattern = '/^([0-9]{1,2})?\s*?([\w\s\+:,]+?)\s*?(\|([a-z,]{2,}))?\s*?(CD([0-9]{1}))?$/';
		if (!preg_match($pattern, $this->mInput, $matches))
		    $this->_trigger_error('Bad Input Format. Type !subhelp for more info'); 
		// $matches[1] - Results
		// $matches[2] - Movie Name
		// $matches[3] - Lang
		// $matches[4] - CDs 
		$this->mNumResults    = ($matches[1] != '') ? $matches[1] : $this->mNumResults;
		$this->mMovieName     =  $matches[2];
		$this->mLang          = ($matches[3] != '') ? $matches[3] : NULL;
		$this->mSumFiles      = ($matches[4] != '') ? $matches[4] : NULL;
		
		// Setting Language
		$this->_process_input_lang();
	}
	
	function _process_input_lang()
	{
		// Using default language
		if ($this->mLang == NULL || (!strpos($this->mLang, ',') && !array_key_exists($this->mLang, $this->mLangs)))
		{
			$this->mLang = &$this->mDefLang;
			return;
		}
		// Using user defined language
		if  (array_key_exists($this->mLang, $this->mLangs))
		{
			$this->mLang = &$this->mLangs[$this->mLang];
			return;
		}
		
		$langs       = explode(',', $this->mLang);
		$this->mLang = '';
		foreach ($langs as $lang)
			if (array_key_exists($lang, $this->mLangs))
			    $this->mLang .= $this->mLangs[$lang].',';
	    if ($this->mLang != '')
	    	$this->mLang = substr($this->mLang, 0, strlen($this->mLang) - 1);
	    else
	        $this->mLang = &$this->mDefLang;
	}
	
	function _trigger_error($errmsg)
	{
		die($this->_format_line($errmsg));
	}
	
	function _clear_Opensub_content()
	{
		$this->mContent = NULL;
	}
		
	
	function _get_opensub_simplexml()
	{
		$url_addition  = '/sublanguageid-'.$this->mLang;
		$url_addition .= ($this->mSumFiles != '') ? '/subsumcd-'.$this->mSumFiles  : '';
		$XmlHTTP = &new XmlHTTP;
		$XmlHTTP->setHost($this->mHost.'/search/moviename-'.urlencode($this->mMovieName).$url_addition.'/simplexml/sourceid-ircbot_v0.1');
		$XmlHTTP->setPort(80);
		$XmlHTTP->setMethod('GET');
		$XmlHTTP->setUserAgent('IrcBot v0.1');
		$this->mContent = $this->_reencode_content($XmlHTTP->getXmlData());		
		$XmlHTTP = NULL;
		unset($XmlHTTP);
	}
	
	function _reencode_content($content)
	{
		return iconv('UTF-8' , 'CP1250//TRANSLIT', $content);		
	}
	
	function _parse()
	{
		$this->_parse_results();
		$this->_parse_process_time();
		$this->_parse_subtitles();
		$this->_parse_URLS();
	}
	
	function _parse_results()
	{
		preg_match('/<results .+ itemsfound=\'([0-9]+)\'/', $this->mContent, $match);
		$this->mResults = $match[1];
	}
	
	function _parse_process_time()
	{
		preg_match('/<results .+ searchtime=\'([0-9\.]+)\'>/', $this->mContent, $match);
		$this->mProcessTime = $match[1];
	}
	
	function _parse_subtitles()
	{
		preg_match_all('/<movie><\!\[CDATA\[(.+?)\]\]><\/movie>/', $this->mContent, $matches);
		$this->mSubtitles = $matches[1];
	}
	
	function _parse_urls()
	{
		preg_match_all('/<detail>(.+?)<\/detail>/', $this->mContent, $matches);
		$this->mURLS = $matches[1];		
	}

}

/*
 * XMLHTTP class
 * @author: char0n 
 */

// XmlHTTP class
class XmlHTTP
{
    var $mHost;
    var $mPort = 80;
    var $mReturnResponse = TRUE;
    var $mTimeout = 30;
    var $mUserAgent = 'Mozilla';
    var $mReturnHeaders = FALSE;
    var $mProxy = NULL;
    var $mSocket;
    var $mMethod = 'GET';
    var $mPostVars;
    var $mXmlData;

    // Public method
    function setHost($host)
    {
		$this->mHost = $host;
    }

    // Public method
    function setPort($port)
    {
		$this->mPort = $port;
    }

    // Public method
    function setReturnResponse($response)
    {
		$this->mReturnResponse = $response;
    }

    // Public method
    function setTimeout($timeout)
    {
		$this->mTimeout = $timeout;
    }

    // Public method
    function setUserAgent($user_agent)
    {
		$this->mUserAgent = $user_agent;
    }

    // Public method
    function setReturnHeaders($headers)
    {
		$this->mReturnHeaders = $headers;
    }

    // Public method
    function setProxy($proxy)
    {
		$this->mProxy = $proxy;
    }

    // Public method
    function setMethod($method)
    {
		$this->mMethod = $method;
    }

    // Public method
    function setPostVars($postvars)
    {
		$this->mPostVars = $postvars;
    }

    // Public method
    function getXmlData()
    {
		$this->_open_connection();
		$this->_set_options();
		$this->_get_response();
		$this->_close_connection();
		return $this->mXmlData;
    }

    // Private method
    function _open_connection()
    {
		$this->mSocket = curl_init();
    }

    // Private method
    function _close_connection()
    {
		curl_close($this->mSocket);
    }

    // Private method
    function _set_options()
    {
		curl_setopt($this->mSocket, CURLOPT_URL, $this->mHost);
		curl_setopt($this->mSocket, CURLOPT_RETURNTRANSFER, $this->mReturnResponse);
		curl_setopt($this->mSocket, CURLOPT_TIMEOUT, $this->mTimeout);
		curl_setopt($this->mSocket, CURLOPT_PORT, $this->mPort);
		curl_setopt($this->mSocket, CURLOPT_USERAGENT, $this->mUserAgent);
		curl_setopt($this->mSocket, CURLOPT_HEADER, $this->mReturnHeaders); 
		if ($this->mProxy != NULL)
		    curl_setopt($this->mSocket, CURLOPT_PROXY, $this->mProxy); 
		if ($this->mMethod == 'GET')
		    curl_setopt($this->mSocket, URLOPT_HTTPGET, 1); 
		if ($this->mMethod == 'POST')
		{
		    curl_setopt($this->mSocket, CURLOPT_POST, 1); 
		    if ($this->mPortVars != '')
			curl_setopt($this->mSocket, CURLOPT_POSTFIELDS, $this->mPostVars);
		}

    }

    function _get_response()
    {
		$this->mXmlData = curl_exec($this->mSocket) or die('No route to '.$this->mHost);
    }
    
}

$IRCOpensub = &new IRCOpenSub;
#$IRCOpensub->setShowMovieNames();
#$IRCOpensub->setDefLang('en');
$IRCOpensub->setInput($argv[1]);
$IRCOpensub->Process();
$IRCOpensub->Output();
?>
