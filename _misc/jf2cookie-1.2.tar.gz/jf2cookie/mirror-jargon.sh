#!/bin/bash
#
# Mirrors ESR's Jargon File website to $WDIR
#
umask 027
SITE="http://www.catb.org/~esr/jargon/"
WDIR="/var/www-common/jargon/"
#
wget -qm $SITE -nH --cut-dirs=2 -np -L -P $WDIR
#
chgrp -R www-data $WDIR
#
# FIN
#
