#!/usr/bin/ksh

# @(#) 
# @(#) jf2cookie.sh v1.2.20151122
# @(#) 
# @(#) Blame: Kevin Brott <kbrott at gmail dot com>
# @(#)  Date: Sun Nov 22 08:00:00 PST 2015
# @(#)   URL: <http://www.wiccat.net/jf2cookie/>
# @(#) 
# @(#) Converts new-xml-style Jargon File <http://www.catb.org/jargon/> 
# @(#) [>= v4.4.1] to a UNIX cookie file in the current working directory.
# @(#)  
# @(#) Suitable for the unix 'fortune' program [source:  
# @(#) <http://www.ibiblio.org/pub/Linux/games/amusements/fortune/>] or any
# @(#) file-format compliant Wintendo [MS Win #] implementation of it like 
# @(#) wfortune <http://www.progsoc.uts.edu.au/~timj/wfortune/>.
# @(#)  
# @(#) Assumes that $WDIR is defined as the TOP-level DIR of a Jargon File Mirror.
# @(#) See mirror-jargon.sh for example of a working mirror-script.
# @(#) 
# @(#) Also assumes that the GNU-equivalent of each of the commands is available.
# @(#) Change the appropriate PROGRAMS definition to fit your system's locations.
# @(#) This code is mostly portable across SysV systems - but YMMV.
# @(#) On most linux distributions you shouldn't have to change anything but $WDIR.
# @(#) 
# @(#) Arguments:
# @(#)  -d          DEBUG mode [SPAMMY!]
# @(#)  -h, --help  THIS MESSAGE
# @(#) 

# PROGRAMS
AWK="/usr/bin/awk"
ECHO="/bin/echo"
FIND="/usr/bin/find"
HEAD="/usr/bin/head"
LYNX="/usr/bin/lynx"
PRINTF="/usr/bin/printf"
SED="/bin/sed"
STRFILE="/usr/bin/strfile"
TAIL="/usr/bin/tail"
WC="/usr/bin/wc"

# WORKSPACES
TMPA="/tmp/lextmpa"
TMPB="/tmp/lextmpb"
JFILE="${PWD}/jargon-cookie"
WDIR="/var/www-common/jargon"

case "$1" in
  --help|-h) ${AWK} -F\) '/\@\(#\)/{print $NF}' $0 ; exit 1 ; ;;
  -d) DEBUG=1; ;;
  *) DEBUG=0; ;;
esac

# For each Lexicon entries under $WDIR/html/?/
#  * convert them to plaintext
#  * strip the html header and footer lines
#  * concat them to the new cookie file, with the % record-delimiters
#  * strfile the result and you're done.

if [ -f ${JFILE} ] ; then rm ${JFILE} ; fi

for ENTRY in $( ${FIND} $WDIR/html/?/ -type f | sort -f ) ; do

    ${LYNX} -dump -nolist -raw ${ENTRY} > ${TMPA}
    LEN=$(${WC} -l ${TMPA} | ${AWK} '{print $1}')
    TLEN=$(expr ${LEN} - 6)
    HLEN=$(expr ${TLEN} - 4)
    ${TAIL} -${TLEN} ${TMPA} > ${TMPB}
    $HEAD -$HLEN ${TMPB} > ${TMPA}
    cat ${TMPA} >> ${JFILE}
    $ECHO "%" >> ${JFILE}

    if [ ${DEBUG} -gt 0 ]
        then ${PRINTF} "%s\n%%\n" "$(cat ${TMPA})"
        else
            if [ "${FLIP}" = "/" ] ; then FLIP='\'; else FLIP='/'; fi
            ${PRINTF} "${FLIP} \r"
    fi

done

echo 
$STRFILE ${JFILE}

# FIN

