#include <stdio.h>
#include <string.h>
#include <curl/curl.h>

static char msg[] = "Brum!\n";
static int len = 6;
static int pos;

static size_t rd(void *ptr, size_t size, size_t nmemb, void *ignored)
{
  int n = size * nmemb;
  if (pos >= len)
    return 0;
  if (pos + n > len)
    n = len - pos;
  memcpy(ptr, msg+pos, n);
  pos += n;
  return n;
}

int main(void)
{
  curl_global_init(CURL_GLOBAL_ALL);
  CURL *curl = curl_easy_init();
  if (!curl)
    return 1;

  // curl_easy_setopt(curl, CURLOPT_VERBOSE, 1);
  curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 1);
  curl_easy_setopt(curl, CURLOPT_URL, "http://mj.ucw.cz/metaclip/metaclip.cgi/brum");
  curl_easy_setopt(curl, CURLOPT_UPLOAD, 1);
  curl_easy_setopt(curl, CURLOPT_READFUNCTION, rd);
  curl_easy_setopt(curl, CURLOPT_INFILESIZE, len);

  char err[CURL_ERROR_SIZE];
  curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, err);

  CURLcode cc = curl_easy_perform(curl);
  if (cc)
    {
      fprintf(stderr, "CURL failed: %s\n", err);
      return 1;
    }

  long rc;
  cc = curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &rc);
  if (cc)
    {
      fprintf(stderr, "Getinfo failed\n");
      return 1;
    }
  printf("RC %d\n", (int)rc);

  curl_easy_cleanup(curl);
  curl_global_cleanup();
  return 0;
}
