/*
 *	Metaclip -- A simple distributed clipboard for X
 *
 *	(c) 2008 Martin Mares <mj@ucw.cz>
 *
 *	This software may be freely distributed and used according to the terms
 *	of the GNU General Public License v2.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <getopt.h>
#include <curl/curl.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>

#ifdef __GNUC__
#define ATTR(x) __attribute__((x))
#else
#define ATTR(x)
#endif

static int verbose;

static Display *dpy;
static Window win;

static void ATTR(noreturn) die(char *msg, ...)
{
  va_list args;
  va_start(args, msg);
  fputs("metaclip: ", stderr);
  vfprintf(stderr, msg, args);
  fputc('\n', stderr);
  va_end(args);
  if (dpy)
    {
      XBell(dpy, 0);
      XFlush(dpy);
    }
  exit(1);
}

static void verb(char *msg, ...)
{
  if (verbose)
    {
      va_list args;
      va_start(args, msg);
      vfprintf(stderr, msg, args);
      va_end(args);
    }
}

static CURL *curl;
static char errbuf[CURL_ERROR_SIZE];

static void init_curl(char *url)
{
  curl_global_init(CURL_GLOBAL_ALL);
  curl = curl_easy_init();
  if (!curl)
    die("Unable to initialize CURL");

  if (verbose)
    curl_easy_setopt(curl, CURLOPT_VERBOSE, 1);
  else
    curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 1);
  curl_easy_setopt(curl, CURLOPT_URL, url);
  curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, errbuf);
}

static void run_curl(void)
{
  CURLcode cc = curl_easy_perform(curl);
  if (cc)
    die("CURL failed: %s", errbuf);

  long rc;
  cc = curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &rc);
  if (cc)
    die("CURL getinfo failed");
  if (rc >= 400)
    die("HTTP request failed: error %d", (int)rc);

  curl_easy_cleanup(curl);
  curl_global_cleanup();
}

/* The clipboard functions have been inspired by the `xclip' utility by Kim Saunders. */

static unsigned char *clipbuf;
static int clippos, cliplen;

static size_t clip_rd(void *ptr, size_t size, size_t nmemb, void *ignored ATTR(unused))
{
  int n = size * nmemb;
  if (clippos >= cliplen)
    return 0;
  if (clippos + n > cliplen)
    n = cliplen - clippos;
  memcpy(ptr, clipbuf+clippos, n);
  clippos += n;
  return nmemb;
}

static size_t clip_wr(void *ptr, size_t size, size_t nmemb, void *ignored ATTR(unused))
{
  int n = size * nmemb;
  if (!clipbuf)
    {
      cliplen = n;
      clipbuf = malloc(cliplen);
    }
  else if (clippos + n > cliplen)
    {
      cliplen = 2*cliplen;
      if (cliplen < clippos + n)
	cliplen = clippos + n;
      clipbuf = realloc(clipbuf, cliplen);
    }
  if (!clipbuf)
    die("Out of memory (cannot get %d bytes)", cliplen);
  memcpy(clipbuf+clippos, ptr, n);
  clippos += n;
  return nmemb;
}

static size_t clip_null_wr(void *ptr ATTR(unused), size_t size ATTR(unused), size_t nmemb, void *ignored ATTR(unused))
{
  return nmemb;
}

static void x_init(void)
{
  /* Create display and window */
  if (!(dpy = XOpenDisplay(NULL)))
    die("Cannot open display");
  win = XCreateSimpleWindow(dpy, DefaultRootWindow(dpy), 0, 0, 1, 1, 0, 0, 0);
}

static void clip_send(void)
{
  /* Select which events we want to listen to */
  XSelectInput(dpy, win, PropertyChangeMask);

  /* Atoms we will need */
  Atom pty = XInternAtom(dpy, "METACLIP_CONTENTS", False);
  Atom incr = XInternAtom(dpy, "INCR", False);

  /* Request the selection */
  XConvertSelection(dpy, XA_PRIMARY, XA_STRING, pty, win, CurrentTime);

  /* Wait for the right event */
  XEvent ev;
  do
    XNextEvent(dpy, &ev);
  while (ev.type != SelectionNotify);

  /* Read type and length of our property */
  Atom pty_type;
  int pty_format;
  unsigned long pty_items, pty_size;
  XGetWindowProperty(dpy, win, pty, 0, 0, False, AnyPropertyType, &pty_type, &pty_format, &pty_items, &pty_size, &clipbuf);
  XFree(clipbuf);

  /* Check type and format */
  if (pty_type == incr)
    die("Incremental transfer not supported yet");
  if (pty_format != 8)
    die("Unrecognized property format");

  /* Read the contents of the property */
  XGetWindowProperty(dpy, win, pty, 0, pty_size, False, AnyPropertyType, &pty_type, &pty_format, &pty_items, &pty_size, &clipbuf);

  /* Send the contents */
  cliplen = pty_items;
  curl_easy_setopt(curl, CURLOPT_UPLOAD, 1);
  curl_easy_setopt(curl, CURLOPT_READFUNCTION, clip_rd);
  curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, clip_null_wr);
  curl_easy_setopt(curl, CURLOPT_INFILESIZE, cliplen);
  verb("Sending %d bytes\n", cliplen);
  run_curl();

  /* Free the buffer and delete the property (just for completeness) */
  XFree(clipbuf);
  XDeleteProperty(dpy, win, pty);
}

static void clip_recv(void)
{
  curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, clip_wr);
  run_curl();
  verb("Received %d bytes\n", clippos);

  /* Select which events we want to listen to */
  XSelectInput(dpy, win, PropertyChangeMask);

  /* Take hold of the needed atoms */
  Atom targets = XInternAtom(dpy, "TARGETS", False);

  /* Assert ownership of the selection */
  XSetSelectionOwner(dpy, XA_PRIMARY, win, CurrentTime);

  /* Wait for the right event */
  XEvent ev;
  verb("Waiting for events\n");
  for (;;)
    {
      XNextEvent(dpy, &ev);
      if (ev.type == SelectionClear)
	break;
      if (ev.type != SelectionRequest)
	continue;

      Window req_win = ev.xselectionrequest.requestor;
      Atom req_pty = ev.xselectionrequest.property;
      if (ev.xselectionrequest.target == targets)
	{
	  /* We were asked to send a list of supported formats */
	  verb("Type list requested\n");
	  Atom formats[2] = { targets, XA_STRING };
	  XChangeProperty(dpy, req_win, req_pty, targets, 8, PropModeReplace, (unsigned char *) formats, (int) sizeof(formats));
	}
      else
	{
	  /* We were asked to send the contents */
	  verb("Selection contents requested\n");
	  XChangeProperty(dpy, req_win, req_pty, XA_STRING, 8, PropModeReplace, (unsigned char *) clipbuf, cliplen);
	}

      /* Respond with another event */
      XEvent re;
      re.xselection.property = req_pty;
      re.xselection.type = SelectionNotify;
      re.xselection.display = ev.xselectionrequest.display;
      re.xselection.requestor = req_win;
      re.xselection.selection = ev.xselectionrequest.selection;
      re.xselection.target = ev.xselectionrequest.target;
      re.xselection.time = ev.xselectionrequest.time;
      XSendEvent(dpy, req_win, 0, 0, &re);
      XFlush(dpy);
    }
  verb("Selection replaced, good bye!\n");
}

static char *read_real_url(char *file)
{
  char *buf = malloc(1024);
  if (!buf)
    die("Out of memory");
  FILE *f = fopen(file, "r");
  if (!f)
    die("Cannot open %s: %m", file);
  if (!fgets(buf, 1024, f))
    die("Cannot read URL from %s: File is empty", file);
  char *c = strchr(buf, '\n');
  if (c)
    *c = 0;
  fclose(f);
  verb("Real URL: %s", buf);
  return buf;
}

static void ATTR(noreturn) usage(void)
{
  fprintf(stderr, "Usage: metaclip <options> <URL>\n\n\
Options:\n\n\
-f, --file\t\t<URL> is a name of a file to read the real URL from\n\
-s, --send\t\tSend clipboard contents to the server\n\
-r, --receive\t\tReceive clipboard contents from the server\n\
-v, --verbose\t\tIncrease verbosity\n\
");
  exit(1);
}

static const struct option options[] = {
  { "file",	0, NULL, 'f' },
  { "send",	0, NULL, 's' },
  { "receive",	0, NULL, 'r' },
  { "recv",	0, NULL, 'r' },
  { "verbose",	0, NULL, 'v' },
  { NULL,	0, NULL, 0 }
};

int main(int argc, char **argv)
{
  int opt;
  int mode = 0;
  int file = 0;

  while ((opt = getopt_long(argc, argv, "frsv", options, NULL)) >= 0)
    switch (opt)
      {
      case 'f':
	file = 1;
	break;
      case 'r':
      case 's':
	if (mode)
	  usage();
	mode = opt;
	break;
      case 'v':
	verbose++;
	break;
      default:
	usage();
      }
  if (optind != argc-1)
    usage();
  char *url = argv[optind];
  if (!mode)
    usage();
  if (file)
    url = read_real_url(url);

  x_init();
  init_curl(url);
  if (mode == 's')
    clip_send();
  else
    clip_recv();

  return 0;
}
