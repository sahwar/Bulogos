/* Charset conversion and text snippets */

void add_subject_snippet(char **ppos, char *term, char *add);
void add_addr_snippet(char **ppos, char *term, char *add, int add_mbox, int add_personal);
void add_snippet(char **ppos, char *term, char *add);
void add_snippet_raw(char **ppos, char *term, char *add);
void charset_init(void);
