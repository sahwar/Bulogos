/*
 *	Utility Functions
 *
 *	(c) 2005 Martin Mares <mj@ucw.cz>
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include "util.h"

int debug_mode;

void NONRET
die(char *c, ...)
{
  va_list args;
  va_start(args, c);
  fprintf(stderr, "cm: ");
  vfprintf(stderr, c, args);
  fputc('\n', stderr);
  va_end(args);
  exit(1);
}

void
debug(char *c, ...)
{
  if (!debug_mode)
    return;

  va_list args;
  va_start(args, c);
  vfprintf(stderr, c, args);
  fflush(stderr);
  va_end(args);
}

void *
xmalloc(uns size)
{
  void *buf = malloc(size);
  if (!buf)
    die("Unable to allocate %d bytes of memory", size);
  return buf;
}

void *
xrealloc(void *old, uns size)
{
  void *buf = realloc(old, size);
  if (!buf)
    die("Unable to allocate %d bytes of memory", size);
  return buf;
}

char *
xstrdup(char *s)
{
  if (!s)
    return s;
  uns len = strlen(s) + 1;
  char *new = xmalloc(len);
  memcpy(new, s, len);
  return new;
}
