/*
 *	Various Utility Functions (extracted from the UCW Library)
 *
 *	(c) 2005 Martin Mares <mj@ucw.cz>
 */

#ifdef __GNUC__
#define NONRET __attribute__((noreturn))
#define UNUSED __attribute__((unused))
#define likely(x) __builtin_expect((x),1)
#define unlikely(x) __builtin_expect((x),0)
#else
#define NONRET
#define UNUSED
#define likely(x) (x)
#define ulikely(x) (x)
#endif

typedef unsigned int uns;

extern int debug_mode;

void NONRET die(char *x, ...);
void debug(char *x, ...);
void *xmalloc(uns size);
void *xrealloc(void *old, uns size);
char *xstrdup(char *s);
